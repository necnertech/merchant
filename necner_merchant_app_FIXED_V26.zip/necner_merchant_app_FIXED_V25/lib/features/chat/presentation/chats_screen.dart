import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../data/models/chat_models.dart';
import '../state/chat_controller.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ChatController>().loadConversations();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chatCtrl = context.watch<ChatController>();

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: const Color(0xFF075E54), // WhatsApp Business Deep Green
        elevation: 1,
        title: _isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                style: const TextStyle(color: Colors.white, fontSize: 16),
                decoration: InputDecoration(
                  hintText: 'Search chats, orders, customers...',
                  hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.7)),
                  border: InputBorder.none,
                ),
                onChanged: (val) => chatCtrl.setSearchQuery(val),
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Necner Merchant',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 19,
                    ),
                  ),
                  Text(
                    'WhatsApp Business Gateway',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.8),
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
        actions: [
          IconButton(
            tooltip: 'Merchant Tools',
            icon: const Icon(Icons.more_vert_rounded, color: Colors.white),
            onPressed: () => context.push('/tools'),
          ),
          IconButton(
            tooltip: 'WhatsApp Communication Center',
            icon: const Icon(Icons.campaign_rounded, color: Colors.white),
            onPressed: () => context.push('/whatsapp'),
          ),
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search, color: Colors.white),
            onPressed: () {
              setState(() {
                if (_isSearching) {
                  _searchController.clear();
                  chatCtrl.setSearchQuery('');
                  _isSearching = false;
                } else {
                  _isSearching = true;
                }
              });
            },
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            onSelected: (val) {
              if (val == 'refresh') {
                chatCtrl.loadConversations();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'refresh',
                child: Text('Refresh Conversations'),
              ),
              const PopupMenuItem(
                value: 'settings',
                child: Text('Chat Settings'),
              ),
            ],
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Container(
            color: const Color(0xFF054D44),
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildFilterChip('all', 'All', chatCtrl),
                const SizedBox(width: 8),
                _buildFilterChip(
                  'unread',
                  'Unread (${chatCtrl.totalUnreadCount})',
                  chatCtrl,
                  highlight: chatCtrl.totalUnreadCount > 0,
                ),
                const SizedBox(width: 8),
                _buildFilterChip('doctor', 'Appointments', chatCtrl),
                const SizedBox(width: 8),
                _buildFilterChip('ecommerce', 'Store Orders', chatCtrl),
              ],
            ),
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => chatCtrl.loadConversations(),
        color: const Color(0xFF075E54),
        child: _buildBody(chatCtrl),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF25D366), // WhatsApp Action Green
        child: const Icon(Icons.chat, color: Colors.white),
        onPressed: () {
          _showNewChatModal(context);
        },
      ),
    );
  }

  Widget _buildFilterChip(
    String key,
    String label,
    ChatController ctrl, {
    bool highlight = false,
  }) {
    final isSelected = ctrl.activeFilter == key;
    return GestureDetector(
      onTap: () => ctrl.setActiveFilter(key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF25D366)
              : Colors.white.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(16),
          border: highlight && !isSelected
              ? Border.all(color: const Color(0xFF25D366), width: 1.5)
              : null,
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white.withValues(alpha: 0.9),
              fontSize: 12.5,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(ChatController chatCtrl) {
    if (chatCtrl.isLoadingConversations && chatCtrl.filteredConversations.isEmpty) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFF075E54)),
      );
    }

    final conversations = chatCtrl.filteredConversations;

    if (conversations.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.mark_chat_unread_outlined, size: 64, color: Colors.grey.shade400),
              const SizedBox(height: 16),
              Text(
                chatCtrl.searchQuery.isNotEmpty
                    ? 'No conversations matching "${chatCtrl.searchQuery}"'
                    : 'No active chat conversations.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey.shade700, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                'Customer inquiries and order chats will appear here in real time.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey.shade500),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      itemCount: conversations.length,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 76, color: Color(0xFFE5E7EB)),
      itemBuilder: (context, index) {
        final conv = conversations[index];
        return _buildConversationTile(conv);
      },
    );
  }

  Widget _buildConversationTile(ConversationSummary conv) {
    final hasUnread = conv.unreadCount > 0;

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      onTap: () {
        context.push('/chats/${conv.id}');
      },
      leading: Stack(
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: _getServiceColor(conv.serviceKey).withValues(alpha: 0.15),
            child: Text(
              _getInitials(conv.customerName),
              style: TextStyle(
                color: _getServiceColor(conv.serviceKey),
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: Icon(
                _getServiceIcon(conv.serviceKey),
                size: 14,
                color: _getServiceColor(conv.serviceKey),
              ),
            ),
          ),
        ],
      ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              conv.customerName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontWeight: hasUnread ? FontWeight.bold : FontWeight.w600,
                fontSize: 16,
                color: const Color(0xFF111827),
              ),
            ),
          ),
          Text(
            _formatTime(conv.lastMessageTime),
            style: TextStyle(
              fontSize: 12,
              color: hasUnread ? const Color(0xFF25D366) : const Color(0xFF6B7280),
              fontWeight: hasUnread ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Row(
          children: [
            if (!hasUnread)
              const Padding(
                padding: EdgeInsets.only(right: 4),
                child: Icon(Icons.done_all, size: 16, color: Color(0xFF34B7F1)),
              ),
            Expanded(
              child: Text(
                conv.lastMessage,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 14,
                  color: hasUnread ? const Color(0xFF1F2937) : const Color(0xFF6B7280),
                  fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
            if (hasUnread) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFF25D366),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${conv.unreadCount}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showNewChatModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Start Customer Interaction',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: Color(0xFFE8F5E9),
                child: Icon(Icons.person_add, color: Color(0xFF075E54)),
              ),
              title: const Text('New Customer Inquiry'),
              subtitle: const Text('Create a direct chat thread with a customer'),
              onTap: () {
                Navigator.pop(ctx);
                context.push('/chats/1');
              },
            ),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: Color(0xFFE3F2FD),
                child: Icon(Icons.calendar_today, color: Color(0xFF1976D2)),
              ),
              title: const Text('Send Appointment Reminder'),
              subtitle: const Text('Follow up on upcoming schedule'),
              onTap: () {
                Navigator.pop(ctx);
                context.push('/chats/1');
              },
            ),
          ],
        ),
      ),
    );
  }

  String _getInitials(String name) {
    final parts = name.trim().split(' ');
    if (parts.isEmpty || parts[0].isEmpty) return 'C';
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  Color _getServiceColor(String key) {
    switch (key) {
      case 'doctor':
        return const Color(0xFF0284C7); // Sky Blue
      case 'ecommerce':
        return const Color(0xFF059669); // Emerald Green
      case 'restaurant':
        return const Color(0xFFD97706); // Amber
      default:
        return const Color(0xFF075E54);
    }
  }

  IconData _getServiceIcon(String key) {
    switch (key) {
      case 'doctor':
        return Icons.medical_services;
      case 'ecommerce':
        return Icons.shopping_bag;
      case 'restaurant':
        return Icons.restaurant;
      default:
        return Icons.business;
    }
  }

  String _formatTime(String timeStr) {
    if (timeStr.isEmpty) return '';
    try {
      final dt = DateTime.parse(timeStr);
      final hour = dt.hour.toString().padLeft(2, '0');
      final minute = dt.minute.toString().padLeft(2, '0');
      return '$hour:$minute';
    } catch (_) {
      return timeStr.contains(' ') ? timeStr.split(' ').last : timeStr;
    }
  }
}
