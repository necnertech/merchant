import 'package:flutter/material.dart';
import '../../../app/theme/app_colors.dart';

class ChatsSkeletonScreen extends StatelessWidget {
  const ChatsSkeletonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        // WhatsApp Business Chat Filter Chips Bar
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Row(
            children: [
              _buildFilterChip('All', isSelected: true),
              const SizedBox(width: 8),
              _buildFilterChip('Unread (2)', isSelected: false),
              const SizedBox(width: 8),
              _buildFilterChip('Assigned Services', isSelected: false),
            ],
          ),
        ),
        const Divider(height: 1, color: AppColors.borderLight),

        // Preview Chat Item 1
        _buildChatRow(
          initials: 'SJ',
          name: 'Sarah Jenkins',
          message: 'Hello Doctor, can I refill my prescription for Asthmin 50mg?',
          time: '10:48 AM',
          unreadCount: 2,
          serviceTag: 'Doctor & Clinic',
          tagColor: AppColors.primaryEmerald,
        ),

        // Preview Chat Item 2
        _buildChatRow(
          initials: 'MV',
          name: 'Marcus Vance',
          message: 'Pickup ready for Pharmacy Order #10045.',
          time: 'Yesterday',
          unreadCount: 0,
          serviceTag: 'Pharmacy Store',
          tagColor: AppColors.badgeBlue,
        ),

        const SizedBox(height: 32),
        Center(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: const Column(
              children: [
                Icon(Icons.mark_chat_unread_outlined, size: 28, color: AppColors.primaryEmerald),
                SizedBox(height: 8),
                Text(
                  'Unified WhatsApp Business Chat Engine',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Text(
                  'Full interactive 11-type message engine and realtime WebSockets will be wired in Phase 4.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondaryLight),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterChip(String label, {required bool isSelected}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: isSelected ? AppColors.primaryEmerald : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? AppColors.primaryEmerald : AppColors.borderLight,
        ),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
          color: isSelected ? Colors.white : AppColors.textSecondaryLight,
        ),
      ),
    );
  }

  Widget _buildChatRow({
    required String initials,
    required String name,
    required String message,
    required String time,
    required int unreadCount,
    required String serviceTag,
    required Color tagColor,
  }) {
    return ListTile(
      leading: CircleAvatar(
        radius: 24,
        backgroundColor: tagColor.withValues(alpha: 0.15),
        child: Text(
          initials,
          style: TextStyle(
            color: tagColor,
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
        ),
      ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              name,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            time,
            style: TextStyle(
              fontSize: 11,
              color: unreadCount > 0 ? AppColors.primaryEmerald : AppColors.textSecondaryLight,
              fontWeight: unreadCount > 0 ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 3),
          Row(
            children: [
              Expanded(
                child: Text(
                  message,
                  style: TextStyle(
                    fontSize: 12,
                    color: unreadCount > 0 ? AppColors.textPrimaryLight : AppColors.textSecondaryLight,
                    fontWeight: unreadCount > 0 ? FontWeight.w500 : FontWeight.normal,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (unreadCount > 0)
                Container(
                  margin: const EdgeInsets.only(left: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: const BoxDecoration(
                    color: AppColors.accentGreen,
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    unreadCount.toString(),
                    style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            serviceTag,
            style: TextStyle(fontSize: 10, color: tagColor, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
