import 'package:flutter/foundation.dart';
import '../../../app/config/app_config.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/logging/app_logger.dart';
import '../../../core/secure_storage/secure_storage_service.dart';
import '../../../data/models/bootstrap_config.dart';
import '../../../data/repositories/bootstrap_repository.dart';

enum BootstrapStatus {
  initial,
  loading,
  success,
  maintenance,
  forceUpdate,
  error,
}

class BootstrapController extends ChangeNotifier {
  final BootstrapRepository _repository;
  final AppConfig _appConfig;
  final SecureStorageService _storage;

  BootstrapStatus _status = BootstrapStatus.initial;
  AppException? _error;
  BootstrapConfig? _config;

  BootstrapController({
    required BootstrapRepository repository,
    required AppConfig appConfig,
    required SecureStorageService storage,
  })  : _repository = repository,
        _appConfig = appConfig,
        _storage = storage;

  BootstrapStatus get status => _status;
  AppException? get error => _error;
  BootstrapConfig? get config => _config;

  Future<void> executeBootstrap({String currentVersion = AppConstants.defaultAppVersion}) async {
    _status = BootstrapStatus.loading;
    _error = null;
    notifyListeners();

    AppLogger.info('Initiating mobile bootstrap handshake with server...');

    final result = await _repository.fetchBootstrapConfig();

    result.when(
      success: (bootstrapConfig) {
        _config = bootstrapConfig;
        _appConfig.updateFromBootstrap(bootstrapConfig);
        _storage.saveBootstrapConfig(bootstrapConfig.toJson());

        // 1. Check Maintenance Mode
        if (bootstrapConfig.maintenanceMode) {
          AppLogger.warning('Server reports MAINTENANCE_MODE = true.');
          _status = BootstrapStatus.maintenance;
          notifyListeners();
          return;
        }

        // 2. Check Force Update Requirement
        if (bootstrapConfig.forceUpdate ||
            _isVersionLower(currentVersion, bootstrapConfig.minimumAppVersion)) {
          AppLogger.warning('App version $currentVersion is below required ${bootstrapConfig.minimumAppVersion}.');
          _status = BootstrapStatus.forceUpdate;
          notifyListeners();
          return;
        }

        AppLogger.info('Bootstrap handshake successful. Ready to resolve session.');
        _status = BootstrapStatus.success;
        notifyListeners();
      },
      failure: (exception) {
        AppLogger.error('Bootstrap handshake failed: ${exception.message}');
        _error = exception;
        _status = BootstrapStatus.error;
        notifyListeners();
      },
    );
  }

  static bool _isVersionLower(String current, String minimum) {
    try {
      final curParts = current.split('.').map((e) => int.tryParse(e) ?? 0).toList();
      final minParts = minimum.split('.').map((e) => int.tryParse(e) ?? 0).toList();
      for (var i = 0; i < 3; i++) {
        final c = i < curParts.length ? curParts[i] : 0;
        final m = i < minParts.length ? minParts[i] : 0;
        if (c < m) return true;
        if (c > m) return false;
      }
      return false;
    } catch (_) {
      return false;
    }
  }
}
