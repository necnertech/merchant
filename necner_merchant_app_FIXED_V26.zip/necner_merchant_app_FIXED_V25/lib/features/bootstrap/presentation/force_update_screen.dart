import 'package:flutter/material.dart';
import '../../../app/theme/app_colors.dart';

class ForceUpdateScreen extends StatelessWidget {
  const ForceUpdateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.system_update_rounded,
                size: 80,
                color: AppColors.primaryEmerald,
              ),
              const SizedBox(height: 24),
              const Text(
                'Update Required',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimaryLight,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'A new version of Necner Merchant is available with critical performance and security improvements. Please update to continue.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.textSecondaryLight,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 36),
              ElevatedButton.icon(
                onPressed: () {
                  // Opens native store link in production via url_launcher or native channel
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Redirecting to official app store...'),
                      backgroundColor: AppColors.primaryTeal,
                    ),
                  );
                },
                icon: const Icon(Icons.download_rounded, size: 20),
                label: const Text('Update Now'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
