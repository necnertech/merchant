import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../models/customer_models.dart';
import '../state/customer_controller.dart';
import 'customer_booking_screen.dart';

class CustomerHomeScreen extends StatefulWidget {
  const CustomerHomeScreen({super.key});

  @override
  State<CustomerHomeScreen> createState() => _CustomerHomeScreenState();
}

class _CustomerHomeScreenState extends State<CustomerHomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctrl = context.read<CustomerController>();
      ctrl.loadServices();
      ctrl.loadRequests();
      ctrl.loadNotifications();
    });
  }

  @override
  Widget build(BuildContext context) {
    final customerCtrl = context.watch<CustomerController>();
    final customer = customerCtrl.currentCustomer;

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: const Text('Necner Services'),
        backgroundColor: const Color(0xFF075E54),
        actions: [
          IconButton(
            icon: const Icon(Icons.chat_bubble_outline, color: Colors.white),
            tooltip: 'Chat with Merchant',
            onPressed: () => context.go('/chats/1'),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none, color: Colors.white),
            tooltip: 'Customer Notifications',
            onPressed: () => _showNotificationsSheet(context, customerCtrl),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await customerCtrl.loadServices();
          await customerCtrl.loadRequests();
        },
        color: AppColors.primaryEmerald,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Customer Greeting & Mode Banner
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF075E54), Color(0xFF128C7E)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 22,
                      backgroundColor: Colors.white.withValues(alpha: 0.25),
                      child: Text(
                        (customer?.name.isNotEmpty ?? false) ? customer!.name[0].toUpperCase() : 'C',
                        style: const TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hello, ${customer?.name ?? "Customer"}',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                          const SizedBox(height: 2),
                          const Text(
                            'Customer Portal · Connected to Verified Merchant',
                            style: TextStyle(fontSize: 11.5, color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.white70),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        minimumSize: const Size(60, 30),
                      ),
                      onPressed: () => context.go('/services'),
                      child: const Text('Merchant Mode', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Available Services Section
              const Text(
                'Available Services & Offerings',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
              ),
              const SizedBox(height: 10),

              if (customerCtrl.isLoading && customerCtrl.services.isEmpty)
                const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
              else
                ...customerCtrl.services.map((svc) => _buildServiceCard(context, svc)),

              const SizedBox(height: 20),

              // Recent Requests & Bookings Tracker
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'My Active Requests & Bookings',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
                  ),
                  Text(
                    '${customerCtrl.requests.length} active',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              if (customerCtrl.requests.isEmpty)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: const Center(
                    child: Text('No active requests yet. Book a service above to begin.', style: TextStyle(color: Colors.grey)),
                  ),
                )
              else
                ...customerCtrl.requests.map(_buildRequestTile),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildServiceCard(BuildContext context, CustomerServiceOffering svc) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderLight),
      ),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: const Color(0xFFDCFCE7),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(_getIcon(svc.icon), color: const Color(0xFF166534), size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(svc.serviceName, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold)),
                    Text(svc.category, style: const TextStyle(fontSize: 11.5, color: Colors.grey)),
                  ],
                ),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF075E54),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  minimumSize: const Size(60, 32),
                ),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => CustomerBookingScreen(service: svc)),
                  );
                },
                child: const Text('Book Now', style: TextStyle(color: Colors.white, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(svc.description, style: const TextStyle(fontSize: 12, color: Color(0xFF4B5563))),
        ],
      ),
    );
  }

  Widget _buildRequestTile(CustomerServiceRequest req) {
    final isConfirmed = req.status.toLowerCase() == 'confirmed';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isConfirmed ? const Color(0xFFDCFCE7) : const Color(0xFFE0F2FE),
          child: Icon(
            isConfirmed ? Icons.check_circle_outline : Icons.schedule,
            size: 20,
            color: isConfirmed ? const Color(0xFF166534) : const Color(0xFF0284C7),
          ),
        ),
        title: Text(req.title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.bold)),
        subtitle: Text(
          'Service: ${req.serviceKey.toUpperCase()} · Status: ${req.status.toUpperCase()}',
          style: TextStyle(
            fontSize: 11,
            color: isConfirmed ? const Color(0xFF166534) : const Color(0xFF0284C7),
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: const Icon(Icons.arrow_forward_ios, size: 12, color: Colors.grey),
        onTap: () => context.go('/chats/1'),
      ),
    );
  }

  void _showNotificationsSheet(BuildContext context, CustomerController ctrl) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Customer Notifications', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              ...ctrl.notifications.map((n) {
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.notifications_active, color: Color(0xFF075E54), size: 20),
                  title: Text(n['title']?.toString() ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: Text(n['body']?.toString() ?? '', style: const TextStyle(fontSize: 11.5)),
                );
              }),
            ],
          ),
        );
      },
    );
  }

  IconData _getIcon(String iconKey) {
    switch (iconKey) {
      case 'medical_services':
        return Icons.medical_services_outlined;
      case 'shopping_bag':
        return Icons.shopping_bag_outlined;
      case 'spa':
        return Icons.spa_outlined;
      default:
        return Icons.business_center_outlined;
    }
  }
}
