import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../models/customer_models.dart';
import '../state/customer_controller.dart';

class CustomerBookingScreen extends StatefulWidget {
  final CustomerServiceOffering service;

  const CustomerBookingScreen({super.key, required this.service});

  @override
  State<CustomerBookingScreen> createState() => _CustomerBookingScreenState();
}

class _CustomerBookingScreenState extends State<CustomerBookingScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedOffering;
  final TextEditingController _notesController = TextEditingController();
  final TextEditingController _dateTimeController = TextEditingController(text: 'Tomorrow 10:30 AM');
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    if (widget.service.offerings.isNotEmpty) {
      _selectedOffering = widget.service.offerings.first['name']?.toString();
    }
  }

  @override
  void dispose() {
    _notesController.dispose();
    _dateTimeController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSubmitting = true);

    final customerCtrl = context.read<CustomerController>();
    final isOrder = widget.service.serviceKey == 'ecommerce';
    final isBooking = widget.service.serviceKey == 'booking';

    final actionKey = isOrder
        ? 'place_order'
        : (isBooking ? 'reserve_slot' : 'request_appointment');

    final payload = {
      'offering': _selectedOffering,
      'date_time': _dateTimeController.text.trim(),
      'notes': _notesController.text.trim(),
      'service_name': widget.service.serviceName,
    };

    final success = await customerCtrl.submitRequest(
      serviceKey: widget.service.serviceKey,
      actionKey: actionKey,
      data: payload,
    );

    if (mounted) {
      setState(() => _isSubmitting = false);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Request submitted to merchant successfully!'),
            backgroundColor: Color(0xFF059669),
          ),
        );
        Navigator.of(context).pop();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(customerCtrl.errorMessage ?? 'Submission failed.'),
            backgroundColor: AppColors.badgeRed,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text('Book with ${widget.service.serviceName}'),
        backgroundColor: const Color(0xFF075E54),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.service.description,
                style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
              ),
              const SizedBox(height: 20),

              // Offering Selection Dropdown
              const Text('Select Service / Treatment', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                initialValue: _selectedOffering,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
                items: widget.service.offerings.map((off) {
                  final name = off['name']?.toString() ?? '';
                  final price = off['price'] != null ? ' (\$${off['price']})' : '';
                  return DropdownMenuItem<String>(
                    value: name,
                    child: Text('$name$price', style: const TextStyle(fontSize: 13)),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedOffering = val),
              ),
              const SizedBox(height: 16),

              // Preferred Date & Time
              const Text('Preferred Date & Time', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(height: 6),
              TextFormField(
                controller: _dateTimeController,
                decoration: InputDecoration(
                  hintText: 'e.g. Tomorrow 10:30 AM',
                  prefixIcon: const Icon(Icons.calendar_today, size: 18),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Please specify preferred time' : null,
              ),
              const SizedBox(height: 16),

              // Special Notes / Reason for Visit
              const Text('Special Notes or Symptoms', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(height: 6),
              TextFormField(
                controller: _notesController,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'Describe details for the provider...',
                  contentPadding: const EdgeInsets.all(12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF075E54),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: _isSubmitting ? null : _submit,
                  child: _isSubmitting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                      : const Text(
                          'Submit Request to Merchant',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
