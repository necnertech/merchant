import 'package:flutter/foundation.dart';

@immutable
class CustomerProfile {
  final int id;
  final String uuid;
  final String name;
  final String email;
  final String phone;
  final String role;
  final int tenantId;
  final String? avatarUrl;

  const CustomerProfile({
    required this.id,
    required this.uuid,
    required this.name,
    required this.email,
    required this.phone,
    this.role = 'customer',
    this.tenantId = 17,
    this.avatarUrl,
  });

  factory CustomerProfile.fromJson(Map<String, dynamic> json) {
    return CustomerProfile(
      id: (json['id'] as num?)?.toInt() ?? 1,
      uuid: json['customer_uuid']?.toString() ?? '',
      name: json['name']?.toString() ?? 'Customer',
      email: json['email']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
      role: json['role']?.toString() ?? 'customer',
      tenantId: (json['tenant_id'] as num?)?.toInt() ?? 17,
      avatarUrl: json['avatar_url']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'customer_uuid': uuid,
    'name': name,
    'email': email,
    'phone': phone,
    'role': role,
    'tenant_id': tenantId,
    'avatar_url': avatarUrl,
  };
}

@immutable
class CustomerServiceOffering {
  final String serviceKey;
  final String serviceName;
  final String category;
  final String icon;
  final String description;
  final List<Map<String, dynamic>> offerings;

  const CustomerServiceOffering({
    required this.serviceKey,
    required this.serviceName,
    required this.category,
    required this.icon,
    required this.description,
    this.offerings = const [],
  });

  factory CustomerServiceOffering.fromJson(Map<String, dynamic> json) {
    final rawOfferings = json['offerings'] as List<dynamic>? ?? [];
    return CustomerServiceOffering(
      serviceKey: json['service_key']?.toString() ?? '',
      serviceName: json['service_name']?.toString() ?? 'Service',
      category: json['category']?.toString() ?? 'General',
      icon: json['icon']?.toString() ?? 'grid',
      description: json['description']?.toString() ?? '',
      offerings: rawOfferings.map((o) => Map<String, dynamic>.from(o as Map)).toList(),
    );
  }
}

@immutable
class CustomerServiceRequest {
  final String id;
  final String requestId;
  final String serviceKey;
  final String moduleKey;
  final String requestType; // 'order', 'appointment', 'booking'
  final String title;
  final String status;
  final Map<String, dynamic> data;
  final String createdAt;

  const CustomerServiceRequest({
    required this.id,
    required this.requestId,
    required this.serviceKey,
    required this.moduleKey,
    required this.requestType,
    required this.title,
    required this.status,
    required this.data,
    required this.createdAt,
  });

  factory CustomerServiceRequest.fromJson(Map<String, dynamic> json) {
    return CustomerServiceRequest(
      id: json['id']?.toString() ?? '',
      requestId: json['request_id']?.toString() ?? '',
      serviceKey: json['service_key']?.toString() ?? 'general',
      moduleKey: json['module_key']?.toString() ?? 'requests',
      requestType: json['request_type']?.toString() ?? 'appointment',
      title: json['title']?.toString() ?? 'Service Request',
      status: json['status']?.toString() ?? 'submitted',
      data: json['data'] is Map ? Map<String, dynamic>.from(json['data'] as Map) : {},
      createdAt: json['created_at']?.toString() ?? '',
    );
  }
}
