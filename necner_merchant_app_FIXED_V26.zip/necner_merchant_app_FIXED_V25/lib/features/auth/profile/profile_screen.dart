import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../../app/config/app_config.dart';
import '../../../app/theme/app_colors.dart';
import '../../../data/repositories/profile_repository.dart';
import '../session/auth_controller.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _saving = false;

  ImageProvider<Object>? _profileImage(XFile? picked, String? avatarUrl) {
    if (picked != null) return FileImage(File(picked.path));
    if (avatarUrl != null && avatarUrl.isNotEmpty) {
      return NetworkImage(avatarUrl);
    }
    return null;
  }

  Future<void> _editBusinessProfile() async {
    final auth = context.read<AuthController>();
    final session = auth.currentSession;
    if (session == null) return;

    final nameCtrl = TextEditingController(text: session.tenant.name);
    XFile? picked;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          return Padding(
            padding: EdgeInsets.only(
              left: 20,
              right: 20,
              top: 20,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Business Profile',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                Center(
                  child: InkWell(
                    onTap: () async {
                      final img = await ImagePicker().pickImage(
                        source: ImageSource.gallery,
                        imageQuality: 85,
                      );
                      if (img != null) {
                        setSheet(() => picked = img);
                      }
                    },
                    child: CircleAvatar(
                      radius: 42,
                      backgroundColor: AppColors.primaryEmerald,
                      backgroundImage:
                          _profileImage(picked, session.user.avatarUrl),
                      child: picked == null &&
                              (session.user.avatarUrl == null ||
                                  session.user.avatarUrl!.isEmpty)
                          ? const Icon(
                              Icons.business,
                              size: 42,
                              color: Colors.white,
                            )
                          : null,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                const Center(
                  child: Text(
                    'Tap logo to change',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Merchant / Business Name',
                    prefixIcon: Icon(Icons.store),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saving
                        ? null
                        : () async {
                            if (nameCtrl.text.trim().isEmpty) return;
                            setSheet(() => _saving = true);
                            final result = await context
                                .read<ProfileRepository>()
                                .updateProfile(
                                  businessName: nameCtrl.text,
                                  logoPath: picked?.path,
                                );
                            if (!mounted) return;
                            result.when(
                              success: (updated) {
                                context
                                    .read<AuthController>()
                                    .applyProfileUpdate(updated);
                                Navigator.of(ctx).pop();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'Business profile updated successfully',
                                    ),
                                  ),
                                );
                              },
                              failure: (err) {
                                setSheet(() => _saving = false);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(err.message)),
                                );
                              },
                            );
                          },
                    child: _saving
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Text('Save Changes'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    nameCtrl.dispose();
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Confirm Logout'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );

    if (ok == true && mounted) {
      await context.read<AuthController>().logout();
      if (mounted) context.go('/login');
    }
  }

  Widget _row(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textSecondaryLight,
          ),
        ),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimaryLight,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final cfg = context.watch<AppConfig>();
    final session = auth.currentSession;
    final avatar = session?.user.avatarUrl;

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            onPressed: () => context.push('/tools'),
            tooltip: 'Merchant Tools',
            icon: const Icon(Icons.more_vert_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 34,
                      backgroundColor: AppColors.primaryEmerald,
                      backgroundImage: _profileImage(null, avatar),
                      child: (avatar == null || avatar.isEmpty)
                          ? const Icon(
                              Icons.business,
                              size: 34,
                              color: Colors.white,
                            )
                          : null,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            session?.tenant.name ?? 'Business',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            session?.user.email ?? '',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: _editBusinessProfile,
                      icon: const Icon(
                        Icons.edit,
                        color: AppColors.primaryEmerald,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _editBusinessProfile,
                    icon: const Icon(Icons.storefront),
                    label: const Text('Edit Business Profile'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: ListTile(
              leading: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F5E9),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.manage_accounts_outlined, color: AppColors.primaryTeal),
              ),
              title: const Text('Profile Settings', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('My Profile, Team, Users & Staff and account settings'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => context.push('/profile/settings'),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Tenant Organization',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Column(
              children: [
                _row('Business Name', session?.tenant.name ?? 'Unknown'),
                const Divider(height: 16),
                _row('Tenant ID', '#${session?.tenant.id ?? '—'}'),
                const Divider(height: 16),
                _row(
                  'Industry',
                  session?.tenant.businessType ?? 'Multi-Service',
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Gateway Runtime Configuration',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Column(
              children: [
                _row('Active API Base URL', cfg.apiBaseUrl),
                const Divider(height: 16),
                _row(
                  'Realtime Gateway',
                  cfg.realtimeBaseUrl.isNotEmpty
                      ? cfg.realtimeBaseUrl
                      : 'Fast polling fallback',
                ),
                const Divider(height: 16),
                _row('Config Version', 'v${cfg.configVersion}'),
              ],
            ),
          ),
          const SizedBox(height: 18),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('Logout', style: TextStyle(color: Colors.red)),
            onTap: _logout,
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
