import 'package:flutter/material.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/config/remote_config_service.dart';

class AdminGovernanceScreen extends StatefulWidget {
  final RemoteConfigService configService;

  const AdminGovernanceScreen({
    super.key,
    required this.configService,
  });

  @override
  State<AdminGovernanceScreen> createState() => _AdminGovernanceScreenState();
}

class _AdminGovernanceScreenState extends State<AdminGovernanceScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late TextEditingController _apiUrlCtrl;
  late TextEditingController _realtimeUrlCtrl;
  late TextEditingController _minVersionCtrl;
  late TextEditingController _updateMsgCtrl;
  bool _forceUpdate = false;
  bool _maintenanceMode = false;

  late Map<String, bool> _flags;
  late Map<String, Map<String, dynamic>> _serviceGov;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _apiUrlCtrl = TextEditingController(text: widget.configService.apiBaseUrl);
    _realtimeUrlCtrl = TextEditingController(text: widget.configService.realtimeBaseUrl);
    _minVersionCtrl = TextEditingController(text: widget.configService.minimumAppVersion);
    _updateMsgCtrl = TextEditingController(text: widget.configService.updateMessage);
    _forceUpdate = widget.configService.forceUpdate;
    _maintenanceMode = widget.configService.maintenanceMode;

    _flags = Map.from(widget.configService.featureFlags);
    _serviceGov = Map.from(widget.configService.serviceGovernance);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _apiUrlCtrl.dispose();
    _realtimeUrlCtrl.dispose();
    _minVersionCtrl.dispose();
    _updateMsgCtrl.dispose();
    super.dispose();
  }

  void _saveConfiguration() {
    final updated = {
      'config_version': widget.configService.configVersion,
      'api_base_url': _apiUrlCtrl.text.trim(),
      'realtime_base_url': _realtimeUrlCtrl.text.trim(),
      'minimum_app_version': _minVersionCtrl.text.trim(),
      'force_update': _forceUpdate,
      'update_message': _updateMsgCtrl.text.trim(),
      'maintenance_mode': _maintenanceMode,
      'feature_flags': _flags,
      'service_governance': _serviceGov,
    };

    widget.configService.applyConfig(updated);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Configuration updated and published locally.'),
        backgroundColor: AppColors.primary,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Service Governance'),
        backgroundColor: AppColors.surface,
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          tabs: const [
            Tab(icon: Icon(Icons.dashboard_outlined), text: 'Overview'),
            Tab(icon: Icon(Icons.settings_input_component_outlined), text: 'Connection & Version'),
            Tab(icon: Icon(Icons.toggle_on_outlined), text: 'Feature Flags'),
            Tab(icon: Icon(Icons.domain_verification_outlined), text: 'Services'),
            Tab(icon: Icon(Icons.security_outlined), text: 'Emergency & Readiness'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildOverviewTab(),
          _buildConnectionTab(),
          _buildFeatureFlagsTab(),
          _buildServicesTab(),
          _buildEmergencyTab(),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: ElevatedButton.icon(
          onPressed: _saveConfiguration,
          icon: const Icon(Icons.cloud_upload_outlined),
          label: const Text('Publish Configuration Changes'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
      ),
    );
  }

  Widget _buildOverviewTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildStatusHeader(),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Active Environment', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.green.shade900,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text('PRODUCTION', style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(width: 12),
                    Text('Version: ${widget.configService.configVersion}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatusHeader() {
    return Card(
      color: AppColors.primary.withValues(alpha: 0.1),
      child: const Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(Icons.shield_outlined, color: AppColors.primary, size: 28),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Enterprise Governance Active', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text('Remote policies are authoritative. Zero app rebuilds required for routine configuration changes.', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectionTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(
          controller: _apiUrlCtrl,
          decoration: const InputDecoration(labelText: 'API Base URL', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _realtimeUrlCtrl,
          decoration: const InputDecoration(labelText: 'Realtime SSE/WebSocket Base URL', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _minVersionCtrl,
          decoration: const InputDecoration(labelText: 'Minimum Supported App Version', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('Force Update Gating'),
          subtitle: const Text('Block clients running versions older than minimum app version'),
          value: _forceUpdate,
          onChanged: (v) => setState(() => _forceUpdate = v),
        ),
      ],
    );
  }

  Widget _buildFeatureFlagsTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: _flags.keys.map((key) {
        final label = key.replaceAll('_', ' ').toUpperCase();
        return SwitchListTile(
          title: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          subtitle: Text('Remote flag: $key', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          value: _flags[key] ?? true,
          onChanged: (v) => setState(() => _flags[key] = v),
        );
      }).toList(),
    );
  }

  Widget _buildServicesTab() {
    final services = ['doctor', 'ecommerce', 'booking'];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: services.map((s) {
        final gov = _serviceGov[s] ?? {'active': true, 'merchant_enabled': true, 'customer_enabled': true};
        final active = gov['active'] as bool? ?? true;
        final cust = gov['customer_enabled'] as bool? ?? true;
        final merch = gov['merchant_enabled'] as bool? ?? true;

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Text('Service: ${s.toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              SwitchListTile(
                title: const Text('Service Globally Active'),
                value: active,
                onChanged: (v) {
                  setState(() {
                    gov['active'] = v;
                    _serviceGov[s] = gov;
                  });
                },
              ),
              SwitchListTile(
                title: const Text('Customer App Visibility'),
                value: cust,
                onChanged: (v) {
                  setState(() {
                    gov['customer_enabled'] = v;
                    _serviceGov[s] = gov;
                  });
                },
              ),
              SwitchListTile(
                title: const Text('Merchant App Availability'),
                value: merch,
                onChanged: (v) {
                  setState(() {
                    gov['merchant_enabled'] = v;
                    _serviceGov[s] = gov;
                  });
                },
              ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildEmergencyTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          color: Colors.red.shade900.withValues(alpha: 0.2),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              const Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 28),
                  SizedBox(width: 12),
                  Text('Emergency Safe Mode', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold, fontSize: 16)),
                ],
              ),
              const SizedBox(height: 12),
              SwitchListTile(
                title: const Text('Enable Global Maintenance Mode'),
                subtitle: const Text('Suspends all non-admin transactions across the mobile gateway'),
                value: _maintenanceMode,
                onChanged: (v) => setState(() => _maintenanceMode = v),
              ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Text('Remote Provider Status', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              SizedBox(height: 8),
              ListTile(
                leading: Icon(Icons.android, color: Colors.amber),
                title: Text('Firebase Cloud Messaging (FCM)'),
                subtitle: Text('NOT_CONFIGURED — Hostinger credentials pending'),
              ),
              ListTile(
                leading: Icon(Icons.apple, color: Colors.amber),
                title: Text('Apple Push Notification Service (APNs)'),
                subtitle: Text('NOT_CONFIGURED — Apple .p8 key pending'),
              ),
              ListTile(
                leading: Icon(Icons.payment, color: Colors.green),
                title: Text('Payment Gateway (Stripe/PayPal)'),
                subtitle: Text('CONFIGURED — Webhook active (Simulated Settlement)'),
              ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
