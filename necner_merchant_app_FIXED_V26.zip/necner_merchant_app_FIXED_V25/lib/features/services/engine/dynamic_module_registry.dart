import '../../../core/network/api_client.dart';
import '../../../core/result/result.dart';
import '../../../data/models/module_schema_models.dart';
import '../../../data/models/service_models.dart';
import 'service_adapter.dart';

class DynamicServiceAdapter implements MerchantServiceAdapter {
  @override
  final String serviceKey;
  @override
  final String serviceName;
  final ApiClient _apiClient;

  DynamicServiceAdapter({
    required this.serviceKey,
    required this.serviceName,
    required ApiClient apiClient,
  }) : _apiClient = apiClient;

  @override
  Future<Result<ServiceManifest>> loadManifest() async {
    return _apiClient.get<ServiceManifest>(
      '/mobile/services/$serviceKey/manifest',
      parser: (data) => ServiceManifest.fromJson(data as Map<String, dynamic>),
    );
  }

  @override
  Future<Result<List<EntityRecord>>> listRecords(String moduleKey) async {
    return _apiClient.get<List<EntityRecord>>(
      '/mobile/services/data.php',
      queryParameters: {
        'service_key': serviceKey,
        'module_key': moduleKey,
      },
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list.map((item) => EntityRecord.fromJson(item as Map<String, dynamic>)).toList();
        }
        return [];
      },
    );
  }

  @override
  Future<Result<EntityRecord>> getRecordDetail(String moduleKey, String recordId) async {
    return _apiClient.get<EntityRecord>(
      '/mobile/services/data.php',
      queryParameters: {
        'service_key': serviceKey,
        'module_key': moduleKey,
        'record_id': recordId,
      },
      parser: (data) => EntityRecord.fromJson(data as Map<String, dynamic>),
    );
  }

  @override
  Future<Result<Map<String, dynamic>>> executeAction(String actionKey, Map<String, dynamic> payload) async {
    return _apiClient.post<Map<String, dynamic>>(
      '/mobile/services/action.php',
      data: {
        'service_key': serviceKey,
        'action_key': actionKey,
        'data': payload,
      },
      parser: (data) => data as Map<String, dynamic>,
    );
  }
}

/// Registry providing adapters dynamically on demand
class ServiceAdapterRegistry {
  final ApiClient _apiClient;
  final Map<String, MerchantServiceAdapter> _adapters = {};

  ServiceAdapterRegistry(this._apiClient);

  MerchantServiceAdapter getAdapter(String serviceKey, {String serviceName = 'Service'}) {
    return _adapters.putIfAbsent(
      serviceKey,
      () => DynamicServiceAdapter(
        serviceKey: serviceKey,
        serviceName: serviceName,
        apiClient: _apiClient,
      ),
    );
  }
}
