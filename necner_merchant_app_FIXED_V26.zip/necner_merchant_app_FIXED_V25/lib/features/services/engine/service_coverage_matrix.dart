import '../../../data/models/service_models.dart';

class ServiceCoverageItem {
  final String serviceKey;
  final String serviceName;
  final String category;
  final bool active;
  final bool assigned;
  final String manifestStatus;
  final String adapterStatus;
  final int modulesAvailable;
  final bool readSupport;
  final bool writeSupport;
  final bool attachmentSupport;
  final bool chatSupport;
  final bool notificationSupport;
  final bool realtimeSupport;
  final List<String> knownGaps;

  const ServiceCoverageItem({
    required this.serviceKey,
    required this.serviceName,
    required this.category,
    required this.active,
    required this.assigned,
    required this.manifestStatus,
    required this.adapterStatus,
    required this.modulesAvailable,
    required this.readSupport,
    required this.writeSupport,
    required this.attachmentSupport,
    required this.chatSupport,
    required this.notificationSupport,
    required this.realtimeSupport,
    this.knownGaps = const [],
  });

  Map<String, dynamic> toJson() => {
    'service_key': serviceKey,
    'service_name': serviceName,
    'category': category,
    'active': active,
    'assigned': assigned,
    'manifest_status': manifestStatus,
    'adapter_status': adapterStatus,
    'modules_available': modulesAvailable,
    'read_support': readSupport,
    'write_support': writeSupport,
    'attachment_support': attachmentSupport,
    'chat_entity_support': chatSupport,
    'notification_support': notificationSupport,
    'realtime_support': realtimeSupport,
    'known_gaps': knownGaps,
  };
}

class ServiceCoverageMatrix {
  static List<ServiceCoverageItem> buildMatrix({
    required List<ServiceDiscoveryItem> services,
    required Map<String, ServiceManifest> manifests,
  }) {
    return services.map((service) {
      final manifest = manifests[service.serviceKey];
      final modulesCount = manifest?.modules.length ?? 0;
      final hasAvailableModules = manifest?.modules.any((m) => m.capability == CapabilityState.available) ?? false;
      final hasReadOnlyModules = manifest?.modules.any((m) => m.capability == CapabilityState.readOnly) ?? false;

      final knownGaps = <String>[];
      if (service.serviceKey == 'doctor') {
        knownGaps.add('Telehealth video consultation marked NOT_IMPLEMENTED on gateway');
      } else if (service.serviceKey == 'ecommerce') {
        knownGaps.add('Point of sale module marked NOT_IMPLEMENTED on gateway');
        knownGaps.add('Live payment gateway direct settlement pending credentials');
      }

      return ServiceCoverageItem(
        serviceKey: service.serviceKey,
        serviceName: service.serviceName,
        category: service.category,
        active: service.active,
        assigned: service.assigned,
        manifestStatus: manifest != null ? 'LOADED' : 'UNREACHABLE',
        adapterStatus: 'ACTIVE_DYNAMIC_ADAPTER',
        modulesAvailable: modulesCount,
        readSupport: hasAvailableModules || hasReadOnlyModules,
        writeSupport: hasAvailableModules,
        attachmentSupport: true,
        chatSupport: true,
        notificationSupport: true,
        realtimeSupport: true,
        knownGaps: knownGaps,
      );
    }).toList();
  }
}
