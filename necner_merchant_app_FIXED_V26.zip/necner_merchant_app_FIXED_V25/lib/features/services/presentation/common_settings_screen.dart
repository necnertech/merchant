import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../app/config/app_config.dart';
import '../../../app/theme/app_colors.dart';
import '../../../data/models/service_models.dart';
import '../state/services_controller.dart';

/// Common merchant workspace is intentionally separated from service
/// functions. It is loaded from the backend's common_modules metadata and
/// shown only from the Settings entry point.
class CommonSettingsScreen extends StatefulWidget {
  final bool profileOnly;

  const CommonSettingsScreen({super.key, this.profileOnly = false});

  @override
  State<CommonSettingsScreen> createState() => _CommonSettingsScreenState();
}

class _CommonSettingsScreenState extends State<CommonSettingsScreen> {
  bool _loading = true;
  String? _error;
  List<ServiceModule> _modules = const [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final controller = context.read<ServicesController>();
    if (controller.services.isEmpty) {
      await controller.loadAssignedServices();
    }

    final assigned = controller.services;
    if (assigned.isEmpty) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _modules = const [];
        _error = 'No assigned service is available for loading merchant settings.';
      });
      return;
    }

    // The backend returns the same common workspace for every assigned
    // service. Load all assigned manifests and merge/deduplicate so a
    // merchant with multiple services still gets one clean Settings list.
    final merged = <String, ServiceModule>{};
    for (final service in assigned) {
      final manifest = await controller.loadManifest(service.serviceKey);
      if (manifest == null) continue;
      for (final module in manifest.commonModules) {
        merged[module.moduleKey] = module;
      }
    }

    var modules = merged.values.toList()
      ..sort((a, b) {
        final group = a.group.compareTo(b.group);
        if (group != 0) return group;
        return a.sortOrder.compareTo(b.sortOrder);
      });

    if (widget.profileOnly) {
      modules = modules
          .where((m) => m.group.toLowerCase() == 'account')
          .toList(growable: false);
    }

    if (!mounted) return;
    setState(() {
      _modules = modules;
      _loading = false;
      if (_modules.isEmpty) {
        _error = widget.profileOnly
            ? 'No profile/account functions are configured for this merchant.'
            : 'No common merchant settings are configured.';
      }
    });
  }

  Future<void> _openFunction(ServiceModule module) async {
    final route = module.route.trim();
    if (route.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${module.title} is available but has no mobile route configured yet.')),
      );
      return;
    }

    final cfg = context.read<AppConfig>();
    final base = Uri.tryParse(cfg.apiBaseUrl);
    if (base == null) return;

    // apiBaseUrl normally ends in /mobile. Common workspace routes are web
    // routes, so open them from the same host without the /mobile prefix.
    final path = route.startsWith('/') ? route : '/$route';
    final segments = List<String>.from(base.pathSegments);
    if (segments.isNotEmpty && segments.last.toLowerCase() == 'mobile') {
      segments.removeLast();
    }
    final uri = base.replace(pathSegments: [...segments, ...path.split('/').where((e) => e.isNotEmpty)]);

    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unable to open ${module.title}.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.profileOnly ? 'Profile Settings' : 'Settings';
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.primaryEmerald),
      );
    }

    if (_error != null && _modules.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.settings_outlined, size: 48, color: AppColors.textSecondaryLight),
              const SizedBox(height: 12),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    final groups = <String, List<ServiceModule>>{};
    for (final module in _modules) {
      groups.putIfAbsent(module.group.isEmpty ? 'Settings' : module.group, () => []).add(module);
    }

    return RefreshIndicator(
      onRefresh: _load,
      color: AppColors.primaryEmerald,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
        children: [
          _intro(),
          const SizedBox(height: 16),
          ...groups.entries.map((entry) => Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: _group(entry.key, entry.value),
              )),
        ],
      ),
    );
  }

  Widget _intro() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF075E54), Color(0xFF008069)],
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: .15),
                borderRadius: BorderRadius.circular(13),
              ),
              child: const Icon(Icons.settings_outlined, color: Colors.white, size: 26),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                widget.profileOnly
                    ? 'Manage your merchant profile, team and account settings.'
                    : 'Common merchant functions shared across your assigned services.',
                style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.35),
              ),
            ),
          ],
        ),
      );

  Widget _group(String title, List<ServiceModule> modules) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 7),
            child: Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: modules.length,
              separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade200),
              itemBuilder: (_, index) => _tile(modules[index]),
            ),
          ),
        ],
      );

  Widget _tile(ServiceModule module) => ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 4),
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: const Color(0xFFE8F5E9),
            borderRadius: BorderRadius.circular(11),
          ),
          alignment: Alignment.center,
          child: Text(_iconText(module.icon), style: const TextStyle(fontSize: 20)),
        ),
        title: Text(module.title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
        subtitle: module.route.isNotEmpty ? const Text('Merchant function') : const Text('Available in merchant workspace'),
        trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey),
        onTap: () => _openFunction(module),
      );

  String _iconText(String icon) {
    if (icon.isEmpty || icon == 'grid' || icon.startsWith('fa-')) return '⚙️';
    return icon;
  }
}
