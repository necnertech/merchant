import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/network/api_client.dart';
import '../../../core/secure_storage/secure_storage_service.dart';
import '../../../data/models/service_models.dart';
import '../../../app/config/app_config.dart';
import '../engine/dynamic_module_registry.dart';
import '../engine/service_adapter.dart';
import '../state/services_controller.dart';
import 'service_dashboard_view.dart';

class ServiceDetailScreen extends StatefulWidget {
  final String serviceKey;

  const ServiceDetailScreen({super.key, required this.serviceKey});

  @override
  State<ServiceDetailScreen> createState() => _ServiceDetailScreenState();
}

class _ServiceDetailScreenState extends State<ServiceDetailScreen> {
  ServiceManifest? _manifest;
  bool _isLoading = true;
  String? _errorMessage;
  late final MerchantServiceAdapter _adapter;

  @override
  void initState() {
    super.initState();
    final config = context.read<AppConfig>();
    final storage = SecureStorageService();
    final apiClient = ApiClient(config: config, storage: storage, onSessionExpired: () {});
    final registry = ServiceAdapterRegistry(apiClient);
    _adapter = registry.getAdapter(widget.serviceKey);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadManifest();
    });
  }

  Future<void> _loadManifest() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final ctrl = context.read<ServicesController>();
    final manifest = await ctrl.loadManifest(widget.serviceKey);

    if (mounted) {
      setState(() {
        _isLoading = false;
        if (manifest != null) {
          _manifest = manifest;
        } else {
          _errorMessage = ctrl.error?.message ?? 'Failed to load service manifest.';
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(_manifest?.serviceName ?? widget.serviceKey.toUpperCase()),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Settings',
            onPressed: () => context.push('/settings'),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadManifest,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryEmerald),
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline_rounded, size: 48, color: AppColors.badgeRed),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14, color: AppColors.textPrimaryLight),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _loadManifest,
                icon: const Icon(Icons.refresh, size: 18),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    if (_manifest == null) {
      return const Center(child: Text('No manifest data available.'));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Dashboard View with KPIs and module shortcuts
          ServiceDashboardView(
            manifest: _manifest!,
            adapter: _adapter,
            onRefresh: _loadManifest,
          ),

          const SizedBox(height: 20),

          // Explicit Capabilities Section
          const Text(
            'Capabilities & Authorizations',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Column(
              children: _manifest!.capabilities.entries.map((entry) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _formatCapabilityName(entry.key),
                        style: const TextStyle(fontSize: 13, color: AppColors.textPrimaryLight),
                      ),
                      _buildCapabilityBadge(entry.value),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCapabilityBadge(CapabilityState state) {
    Color bg;
    Color text;
    String label;

    switch (state) {
      case CapabilityState.available:
        bg = const Color(0xFFDCFCE7);
        text = const Color(0xFF166534);
        label = 'AVAILABLE';
        break;
      case CapabilityState.readOnly:
        bg = const Color(0xFFE0F2FE);
        text = const Color(0xFF075985);
        label = 'READ ONLY';
        break;
      case CapabilityState.disabled:
        bg = const Color(0xFFF3F4F6);
        text = const Color(0xFF6B7280);
        label = 'DISABLED';
        break;
      case CapabilityState.notImplemented:
        bg = const Color(0xFFFEF3C7);
        text = const Color(0xFF92400E);
        label = 'NOT IMPLEMENTED';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        label,
        style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: text),
      ),
    );
  }

  String _formatCapabilityName(String key) {
    return key
        .replaceAll('_', ' ')
        .split(' ')
        .map((w) => w.isNotEmpty ? w[0].toUpperCase() + w.substring(1) : '')
        .join(' ');
  }
}
