import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/actions/action_definition.dart';
import '../../../core/actions/action_engine.dart';
import '../../../core/permissions/permission_evaluator.dart';
import '../../../data/models/module_schema_models.dart' hide ActionDefinition;
import '../../auth/session/auth_controller.dart';
import '../engine/service_adapter.dart';

class HardenedSchemaFormScreen extends StatefulWidget {
  final MerchantServiceAdapter adapter;
  final ActionDefinition actionDefinition;
  final VoidCallback? onSuccess;

  const HardenedSchemaFormScreen({
    super.key,
    required this.adapter,
    required this.actionDefinition,
    this.onSuccess,
  });

  @override
  State<HardenedSchemaFormScreen> createState() => _HardenedSchemaFormScreenState();
}

class _HardenedSchemaFormScreenState extends State<HardenedSchemaFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _formData = {};
  bool _isDirty = false;
  bool _isSubmitting = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    for (final field in widget.actionDefinition.fields) {
      if (field.defaultValue != null) {
        _formData[field.key] = field.defaultValue;
      }
    }
  }

  Future<bool> _onWillPop() async {
    if (!_isDirty || _isSubmitting) return true;

    final discard = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Discard Unsaved Changes?'),
        content: const Text('You have unsaved changes in this form. If you leave now, your input will be lost.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Continue Editing'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.badgeRed),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Discard', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    return discard ?? false;
  }

  Future<void> _submitForm() async {
    if (_isSubmitting) return; // Prevent duplicate submit
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    setState(() {
      _isSubmitting = true;
      _errorMessage = null;
    });

    final authCtrl = context.read<AuthController>();
    final session = authCtrl.currentSession;
    final evaluator = PermissionEvaluator(
      userPermissions: session?.effectivePermissions ?? [],
      assignedServices: session?.assignedServices ?? [],
    );

    final actionEngine = context.read<ActionEngine>();

    final result = await actionEngine.execute(
      action: widget.actionDefinition,
      payload: _formData,
      permissionEvaluator: evaluator,
      context: context,
    );

    if (mounted) {
      if (result.success) {
        setState(() {
          _isSubmitting = false;
          _isDirty = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${widget.actionDefinition.title} submitted successfully!'),
            backgroundColor: AppColors.primaryEmerald,
          ),
        );

        widget.onSuccess?.call();
        Navigator.of(context).pop(true);
      } else {
        setState(() {
          _isSubmitting = false;
          _errorMessage = result.message;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_isDirty || _isSubmitting,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final shouldPop = await _onWillPop();
        if (shouldPop && context.mounted) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.backgroundLight,
        appBar: AppBar(
          title: Text(widget.actionDefinition.title),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            onChanged: () {
              if (!_isDirty) setState(() => _isDirty = true);
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (widget.actionDefinition.description.isNotEmpty) ...[
                  Text(
                    widget.actionDefinition.description,
                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
                  ),
                  const SizedBox(height: 16),
                ],

                if (_errorMessage != null) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFEE2E2),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFFF87171)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline, size: 20, color: AppColors.badgeRed),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _errorMessage!,
                            style: const TextStyle(fontSize: 12.5, color: Color(0xFF991B1B)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                ...widget.actionDefinition.fields.map(_buildFormField),

                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF075E54),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    onPressed: _isSubmitting ? null : _submitForm,
                    child: _isSubmitting
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                          )
                        : Text(
                            'Submit ${widget.actionDefinition.title}',
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFormField(FieldDefinition field) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                field.label,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimaryLight),
              ),
              if (field.required)
                const Text(' *', style: TextStyle(color: AppColors.badgeRed, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          TextFormField(
            initialValue: _formData[field.key]?.toString() ?? '',
            enabled: !_isSubmitting,
            decoration: InputDecoration(
              hintText: field.placeholder ?? 'Enter ${field.label.toLowerCase()}',
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: AppColors.borderLight),
              ),
            ),
            validator: (value) {
              if (field.required && (value == null || value.trim().isEmpty)) {
                return '${field.label} is required.';
              }
              if (field.min != null && value != null && value.length < field.min!) {
                return '${field.label} must be at least ${field.min} characters.';
              }
              return null;
            },
            onSaved: (value) {
              _formData[field.key] = value?.trim();
            },
          ),
        ],
      ),
    );
  }
}
