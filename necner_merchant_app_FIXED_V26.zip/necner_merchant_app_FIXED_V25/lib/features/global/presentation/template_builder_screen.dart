import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../app/theme/app_colors.dart';
import '../../../app/config/app_config.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import '../../../core/secure_storage/secure_storage_service.dart';

class TemplateBuilderScreen extends StatefulWidget {
  const TemplateBuilderScreen({super.key});
  @override State<TemplateBuilderScreen> createState()=>_TemplateBuilderScreenState();
}

class _TemplateBuilderScreenState extends State<TemplateBuilderScreen> {
  late final ApiClient _api;
  final name=TextEditingController(), body=TextEditingController(), footer=TextEditingController(), header=TextEditingController();
  String category='UTILITY', language='en_US', headerType='NONE';
  final List<_ButtonDraft> buttons=[];
  final List<_CardDraft> cards=[];
  bool saving=false;

  @override void initState(){super.initState();_api=ApiClient(config:context.read<AppConfig>(),storage:SecureStorageService(),onSessionExpired:(){});}
  @override void dispose(){name.dispose();body.dispose();footer.dispose();header.dispose();super.dispose();}

  Future<void> _save() async {
    if(name.text.trim().isEmpty||body.text.trim().isEmpty){_toast('Template name and body are required.');return;}
    setState(()=>saving=true);
    final payload={
      'action':'create','template_name':name.text.trim(),'category':category,'language':language,
      'header_type':headerType,'body':body.text.trim(),'footer':footer.text.trim(),
      'variables':RegExp(r'\{\{\d+\}\}').allMatches(body.text).map((m)=>m.group(0)).toList(),
      'buttons':buttons.map((b)=>b.toJson()).toList(),
      'components':[if(header.text.trim().isNotEmpty){'type':'header','text':header.text.trim()},...cards.map((c)=>c.toJson())],
    };
    final r=await _api.post<Map<String,dynamic>>(ApiEndpoints.global,queryParameters:{'route':'template-create'},data:payload,parser:(d)=>Map<String,dynamic>.from(d as Map));
    if(!mounted)return;
    r.when(success:(d){setState(()=>saving=false);_toast('Template saved as draft.');Navigator.pop(context,true);},failure:(e){setState(()=>saving=false);_toast(e.message);});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: AppColors.primaryTeal,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Create Template', style: TextStyle(fontWeight: FontWeight.w800)),
            Text('Design your WhatsApp template with live preview', style: TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: saving ? null : () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.white)),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: FilledButton(
              onPressed: saving ? null : _save,
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppColors.primaryTeal),
              child: saving
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Submit'),
            ),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth > 900) {
            return Row(
              children: [
                Expanded(child: _editor()),
                SizedBox(width: 390, child: Padding(padding: const EdgeInsets.fromLTRB(10, 14, 14, 14), child: _preview())),
              ],
            );
          }
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [_editor(), const SizedBox(height: 14), _preview()],
          );
        },
      ),
    );
  }

  Widget _editor() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(14, 14, 4, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _panel(
            'Template Details',
            Icons.tune_rounded,
            Column(
              children: [
                Row(
                  children: [
                    Expanded(child: _input(name, 'Template Name', 'order_update')),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _dropdown(
                        'Category',
                        category,
                        ['MARKETING', 'UTILITY', 'AUTHENTICATION'],
                        (v) => setState(() => category = v!),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _dropdown(
                        'Language',
                        language,
                        ['en_US', 'hi', 'en'],
                        (v) => setState(() => language = v!),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _panel(
            'Header (optional)',
            Icons.image_outlined,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final x in const [
                      'NONE',
                      'TEXT',
                      'IMAGE',
                      'VIDEO',
                      'DOCUMENT',
                    ])
                      ChoiceChip(
                        label: Text(x),
                        selected: headerType == x,
                        onSelected: (_) => setState(() => headerType = x),
                      ),
                  ],
                ),
                if (headerType == 'TEXT')
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: _input(header, 'Header text', 'Order update'),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _panel(
            'Body *',
            Icons.text_fields_rounded,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: body,
                  maxLines: 7,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    hintText: 'Message body. Use {{1}}, {{2}} for variables',
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    ActionChip(
                      label: const Text('+ {{1}} Add variable'),
                      onPressed: () {
                        final count = RegExp(r'\{\{\d+\}\}')
                            .allMatches(body.text)
                            .length;
                        body.text = '${body.text} {{${count + 1}}}';
                        body.selection = TextSelection.collapsed(
                          offset: body.text.length,
                        );
                        setState(() {});
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _panel(
            'Footer',
            Icons.notes_rounded,
            _input(footer, 'Footer text (optional)', 'Thank you for your business'),
          ),
          const SizedBox(height: 12),
          _panel(
            'Buttons',
            Icons.smart_button_rounded,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final entry in buttons.asMap().entries)
                  _buttonRow(entry.key, entry.value),
                TextButton.icon(
                  onPressed: () => setState(() => buttons.add(_ButtonDraft())),
                  icon: const Icon(Icons.add),
                  label: const Text('Add Button'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _panel(
            'Carousel Cards',
            Icons.view_carousel_rounded,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'For carousel messages, each card can have its own media, text and 1–2 buttons.',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondaryLight,
                  ),
                ),
                const SizedBox(height: 8),
                for (final entry in cards.asMap().entries)
                  _cardEditor(entry.key, entry.value),
                TextButton.icon(
                  onPressed: () => setState(() => cards.add(_CardDraft())),
                  icon: const Icon(Icons.add_box_rounded),
                  label: const Text('Add Card'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buttonRow(int i, _ButtonDraft b) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(
            width: 125,
            child: _dropdown(
              'Type',
              b.type,
              const ['QUICK_REPLY', 'URL', 'PHONE'],
              (v) => setState(() => b.type = v!),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(child: _input(b.text, 'Button text', 'Pay Now')),
          if (b.type == 'URL') ...[
            const SizedBox(width: 8),
            Expanded(child: _input(b.value, 'URL', 'https://...')),
          ],
          if (b.type == 'PHONE') ...[
            const SizedBox(width: 8),
            Expanded(child: _input(b.value, 'Phone', '+91...')),
          ],
          IconButton(
            onPressed: () => setState(() => buttons.removeAt(i)),
            icon: const Icon(Icons.delete_outline, color: Colors.red),
          ),
        ],
      ),
    );
  }

  Widget _cardEditor(int i, _CardDraft c) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                'Card ${i + 1}',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => setState(() => cards.removeAt(i)),
                icon: const Icon(Icons.delete_outline, color: Colors.red),
              ),
            ],
          ),
          _input(c.media, 'Media URL', 'https://...'),
          const SizedBox(height: 8),
          _input(c.text, 'Card text', 'Up to 160 characters'),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _input(c.button1, 'Button 1', 'View')),
              const SizedBox(width: 8),
              Expanded(child: _input(c.button2, 'Button 2', 'Buy')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _preview() {
    final previewButtons = buttons
        .map(
          (b) => Container(
            width: double.infinity,
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.symmetric(vertical: 7),
            decoration: BoxDecoration(
              color: const Color(0xFFF0FDF4),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                b.text.text.isEmpty ? 'Button' : b.text.text,
                style: const TextStyle(
                  color: Color(0xFF008069),
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        )
        .toList();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Live WhatsApp Preview', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Container(
            height: 500,
            decoration: BoxDecoration(
              color: const Color(0xFFEFE7DB),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: const Color(0xFF0F172A), width: 5),
            ),
            child: Column(
              children: [
                Container(
                  height: 58,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: const BoxDecoration(
                    color: Color(0xFF075E54),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(23),
                      topRight: Radius.circular(23),
                    ),
                  ),
                  child: const Row(
                    children: [
                      CircleAvatar(radius: 16, backgroundColor: Color(0xFF8FD4C5), child: Icon(Icons.business, color: Colors.white)),
                      SizedBox(width: 9),
                      Text('Business', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
                Expanded(
                  child: Center(
                    child: Container(
                      margin: const EdgeInsets.all(16),
                      padding: const EdgeInsets.all(12),
                      constraints: const BoxConstraints(maxWidth: 300),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (headerType == 'TEXT' && header.text.isNotEmpty)
                            Text(header.text, style: const TextStyle(fontWeight: FontWeight.w800)),
                          if (body.text.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Text(
                                body.text.replaceAll(RegExp(r'\{\{\d+\}\}'), 'sample'),
                                style: const TextStyle(fontSize: 13),
                              ),
                            ),
                          if (footer.text.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(footer.text, style: const TextStyle(fontSize: 10, color: Colors.grey)),
                            ),
                          if (previewButtons.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Column(children: previewButtons),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  height: 45,
                  margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _panel(String title,IconData icon,Widget child)=>Container(width:double.infinity,padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(17),border:Border.all(color:AppColors.borderLight)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(icon,color:AppColors.primaryTeal,size:20),const SizedBox(width:8),Text(title,style:const TextStyle(fontWeight:FontWeight.w800))]),const SizedBox(height:12),child]));
  Widget _input(TextEditingController c,String label,String hint)=>TextField(controller:c,onChanged:(_)=>setState((){}),decoration:InputDecoration(labelText:label,hintText:hint));
  Widget _dropdown(String label,String value,List<String> values,ValueChanged<String?> onChanged)=>DropdownButtonFormField<String>(initialValue:value,items:values.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:onChanged,decoration:InputDecoration(labelText:label));
  void _toast(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
}

class _ButtonDraft { String type='QUICK_REPLY'; final text=TextEditingController(); final value=TextEditingController(); Map<String,dynamic> toJson()=>{'type':type,'text':text.text.trim(),if(value.text.trim().isNotEmpty)'value':value.text.trim()}; }
class _CardDraft { final media=TextEditingController(); final text=TextEditingController(); final button1=TextEditingController(); final button2=TextEditingController(); Map<String,dynamic> toJson()=>{'media':media.text.trim(),'text':text.text.trim(),'buttons':[if(button1.text.trim().isNotEmpty){'type':'QUICK_REPLY','text':button1.text.trim()},if(button2.text.trim().isNotEmpty){'type':'QUICK_REPLY','text':button2.text.trim()}]}; }
