import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app/app.dart';
import 'app/config/app_config.dart';
import 'core/actions/action_engine.dart';
import 'core/attachments/attachment_service.dart';
import 'core/logging/app_logger.dart';
import 'core/network/api_client.dart';
import 'core/network/idempotency_service.dart';
import 'core/push/push_notification_service.dart';
import 'core/realtime/realtime_service.dart';
import 'core/secure_storage/secure_storage_service.dart';
import 'core/utils/device_service.dart';
import 'data/models/bootstrap_config.dart';
import 'data/repositories/activity_repository.dart';
import 'data/repositories/auth_repository.dart';
import 'data/repositories/bootstrap_repository.dart';
import 'data/repositories/chat_repository.dart';
import 'data/repositories/call_repository.dart';
import 'data/repositories/profile_repository.dart';
import 'data/repositories/notification_repository.dart';
import 'data/repositories/service_repository.dart';
import 'features/activity/state/activity_controller.dart';
import 'features/auth/session/auth_controller.dart';
import 'features/bootstrap/state/bootstrap_controller.dart';
import 'features/chat/state/chat_controller.dart';
import 'features/customer/state/customer_controller.dart';
import 'features/notifications/state/notifications_controller.dart';
import 'features/services/state/services_controller.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  AppLogger.info('Bootstrapping Necner Merchant mobile container...');

  // 1. Core Infrastructure & Hardware Storage
  final storage = SecureStorageService();
  final deviceService = DeviceService(storage);

  final cachedBootstrapJson = await storage.getBootstrapConfig();
  BootstrapConfig? cachedBootstrap;
  if (cachedBootstrapJson != null) {
    try {
      cachedBootstrap = BootstrapConfig.fromJson(cachedBootstrapJson);
    } catch (_) {
      cachedBootstrap = null;
    }
  }

  final appConfig = AppConfig(initialBaseUrl: cachedBootstrap?.apiBaseUrl);
  if (cachedBootstrap != null) {
    appConfig.updateFromBootstrap(cachedBootstrap);
  }

  // Reference for session expiration trigger
  late AuthController authController;

  // 2. Network Client with Single-Flight Refresh Mutex
  final apiClient = ApiClient(
    config: appConfig,
    storage: storage,
    onSessionExpired: () {
      authController.handleSessionExpired();
    },
  );

  // 3. Repositories & Platform Engines
  final bootstrapRepo = BootstrapRepository(apiClient);
  final authRepo = AuthRepository(apiClient: apiClient, storage: storage);
  final serviceRepo = ServiceRepository(apiClient);
  final chatRepo = ChatRepository(apiClient);
  final notifRepo = NotificationRepository(apiClient);
  final callRepo = CallRepository(apiClient);
  final profileRepo = ProfileRepository(apiClient);
  final activityRepo = ActivityRepository(apiClient);

  // 4. Realtime & Native Push Services
  final realtimeService = RealtimeService(apiClient: apiClient);
  final pushService = PushNotificationService(
    repository: notifRepo,
    deviceService: deviceService,
  );

  // 5. Phase 5 Action Engine & Idempotency
  final idempotencyService = IdempotencyService();
  final actionEngine = ActionEngine(
    apiClient: apiClient,
    idempotencyService: idempotencyService,
    realtimeService: realtimeService,
  );
  final attachmentService = AttachmentService(apiClient);

  // 6. Controllers
  final bootstrapController = BootstrapController(
    repository: bootstrapRepo,
    appConfig: appConfig,
    storage: storage,
  );

  authController = AuthController(
    repository: authRepo,
    storage: storage,
    deviceService: deviceService,
  );

  final servicesController = ServicesController(serviceRepo);

  final chatController = ChatController(
    repository: chatRepo,
    realtimeService: realtimeService,
    merchantNameProvider: () => authController.currentSession?.user.name ?? 'Merchant',
  );

  final notificationsController = NotificationsController(
    repository: notifRepo,
    pushService: pushService,
  );

  final activityController = ActivityController(
    repository: activityRepo,
    realtimeService: realtimeService,
  );

  final customerController = CustomerController(
    apiClient: apiClient,
    realtimeService: realtimeService,
  );

  // Keep authenticated realtime bound to the latest remote URL.
  appConfig.addListener(() {
    if (authController.isAuthenticated && appConfig.realtimeBaseUrl.isNotEmpty) {
      realtimeService.disconnect();
      realtimeService.connect(appConfig.realtimeBaseUrl);
    }
  });

  // Initialize native push token registration once user is authenticated
  authController.addListener(() {
    if (authController.isAuthenticated) {
      // Resolve tenant-specific services first. The Services screen will
      // display only services assigned by the server.
      servicesController.loadAssignedServices().then((_) {
        if (!authController.isAuthenticated) return;
        pushService.initializeAndRegister();
        realtimeService.connect(appConfig.realtimeBaseUrl);
        notificationsController.startFastPolling();
        activityController.loadActivities();
      });
    } else {
      realtimeService.disconnect();
      notificationsController.stopFastPolling();
    }
  });

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppConfig>.value(value: appConfig),
        ChangeNotifierProvider<BootstrapController>.value(value: bootstrapController),
        ChangeNotifierProvider<AuthController>.value(value: authController),
        ChangeNotifierProvider<ServicesController>.value(value: servicesController),
        ChangeNotifierProvider<ChatController>.value(value: chatController),
        ChangeNotifierProvider<NotificationsController>.value(value: notificationsController),
        Provider<CallRepository>.value(value: callRepo),
        Provider<ProfileRepository>.value(value: profileRepo),
        ChangeNotifierProvider<ActivityController>.value(value: activityController),
        ChangeNotifierProvider<CustomerController>.value(value: customerController),
        ChangeNotifierProvider<RealtimeService>.value(value: realtimeService),
        ChangeNotifierProvider<PushNotificationService>.value(value: pushService),
        Provider<ActionEngine>.value(value: actionEngine),
        Provider<IdempotencyService>.value(value: idempotencyService),
        Provider<AttachmentService>.value(value: attachmentService),
      ],
      child: const NecnerMerchantApp(),
    ),
  );
}
