/// Stable error codes returned by the Necner Mobile API Gateway
class ErrorCodes {
  const ErrorCodes._();

  static const String invalidRequest = 'INVALID_REQUEST';
  static const String authenticationRequired = 'AUTHENTICATION_REQUIRED';
  static const String invalidCredentials = 'INVALID_CREDENTIALS';
  static const String invalidToken = 'INVALID_TOKEN';
  static const String tokenExpired = 'TOKEN_EXPIRED';
  static const String forbidden = 'FORBIDDEN';
  static const String serviceNotAssigned = 'SERVICE_NOT_ASSIGNED';
  static const String serviceNotFound = 'SERVICE_NOT_FOUND';
  static const String maintenanceMode = 'MAINTENANCE_MODE';
  static const String configurationError = 'CONFIGURATION_ERROR';
  static const String rateLimited = 'RATE_LIMITED';
  static const String internalError = 'INTERNAL_ERROR';

  // Client-side generated error codes
  static const String networkOffline = 'NETWORK_OFFLINE';
  static const String networkTimeout = 'NETWORK_TIMEOUT';
  static const String forceUpdateRequired = 'FORCE_UPDATE_REQUIRED';
}
