import 'error_codes.dart';

/// Base exception class for all errors in the Necner Merchant app.
/// Maps backend errors safely to user-friendly messages without leaking stack traces or internal secrets.
class AppException implements Exception {
  final String errorCode;
  final String message;
  final int? statusCode;
  final Map<String, dynamic>? details;

  const AppException({
    required this.errorCode,
    required this.message,
    this.statusCode,
    this.details,
  });

  /// Factory to construct from standard backend error JSON
  factory AppException.fromJson(Map<String, dynamic> json, {int? statusCode}) {
    final code = json['error_code'] as String? ?? ErrorCodes.internalError;
    final rawMsg = json['message'] as String? ?? 'An unexpected error occurred.';
    return AppException(
      errorCode: code,
      message: _sanitizeUserMessage(code, rawMsg),
      statusCode: statusCode,
      details: json['details'] as Map<String, dynamic>?,
    );
  }

  /// Client-side network offline exception
  factory AppException.offline() => const AppException(
        errorCode: ErrorCodes.networkOffline,
        message: 'No internet connection. Please check your network and retry.',
        statusCode: 0,
      );

  /// Client-side timeout exception
  factory AppException.timeout() => const AppException(
        errorCode: ErrorCodes.networkTimeout,
        message: 'Request timed out. Please try again.',
        statusCode: 408,
      );

  /// Maps technical error codes to clear, professional user-facing copy
  static String _sanitizeUserMessage(String code, String fallback) {
    switch (code) {
      case ErrorCodes.invalidCredentials:
        return 'Incorrect username/email or password. Please verify your credentials.';
      case ErrorCodes.authenticationRequired:
      case ErrorCodes.invalidToken:
      case ErrorCodes.tokenExpired:
        return 'Your session has expired. Please sign in again.';
      case ErrorCodes.forbidden:
        return 'Access denied. You do not have permission to view this resource.';
      case ErrorCodes.serviceNotAssigned:
        return 'This service is not assigned to your merchant tenant.';
      case ErrorCodes.rateLimited:
        return 'Too many requests. Please wait a moment before trying again.';
      case ErrorCodes.maintenanceMode:
        return 'The platform is currently undergoing maintenance. Please check back shortly.';
      case ErrorCodes.configurationError:
        return 'Unable to load configuration from the server. Please retry.';
      default:
        // Strip SQL or server stack traces if accidentally passed
        if (fallback.toLowerCase().contains('sql') ||
            fallback.toLowerCase().contains('exception') ||
            fallback.toLowerCase().contains('pdo')) {
          return 'A server error occurred. Please contact Necner Support if this persists.';
        }
        return fallback;
    }
  }

  @override
  String toString() => 'AppException($errorCode, message: $message, status: $statusCode)';
}
