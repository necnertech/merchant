import '../errors/app_exception.dart';
import '../logging/app_logger.dart';
import '../network/api_client.dart';
import '../result/result.dart';

class AttachmentMetadata {
  final String attachmentId;
  final String fileName;
  final String storedName;
  final String mimeType;
  final int fileSizeBytes;
  final String serviceKey;
  final String moduleKey;
  final String uploadedAt;

  const AttachmentMetadata({
    required this.attachmentId,
    required this.fileName,
    required this.storedName,
    required this.mimeType,
    required this.fileSizeBytes,
    required this.serviceKey,
    required this.moduleKey,
    required this.uploadedAt,
  });

  factory AttachmentMetadata.fromJson(Map<String, dynamic> json) {
    return AttachmentMetadata(
      attachmentId: json['attachment_id']?.toString() ?? '',
      fileName: json['file_name']?.toString() ?? 'attachment',
      storedName: json['stored_name']?.toString() ?? '',
      mimeType: json['mime_type']?.toString() ?? 'application/octet-stream',
      fileSizeBytes: (json['file_size'] as num?)?.toInt() ?? 0,
      serviceKey: json['service_key']?.toString() ?? 'general',
      moduleKey: json['module_key']?.toString() ?? 'attachments',
      uploadedAt: json['uploaded_at']?.toString() ?? '',
    );
  }
}

class AttachmentService {
  final ApiClient _apiClient;

  static const List<String> allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
    'application/pdf',
  ];

  static const int maxFileSize = 10 * 1024 * 1024; // 10MB

  AttachmentService(this._apiClient);

  /// Validates file properties before uploading
  String? validateFile({required String fileName, required String mimeType, required int sizeBytes}) {
    if (!allowedMimeTypes.contains(mimeType.toLowerCase())) {
      return 'File type "$mimeType" is not supported. Allowed: JPEG, PNG, WEBP, PDF.';
    }
    if (sizeBytes > maxFileSize) {
      return 'File size exceeds maximum allowed 10MB.';
    }
    return null;
  }

  /// Uploads base64 or binary attachment to the backend gateway
  Future<Result<AttachmentMetadata>> uploadAttachment({
    required String serviceKey,
    required String moduleKey,
    required String fileName,
    required String mimeType,
    required String base64Data,
    String? recordId,
  }) async {
    final validationError = validateFile(
      fileName: fileName,
      mimeType: mimeType,
      sizeBytes: (base64Data.length * 3) ~/ 4,
    );

    if (validationError != null) {
      return Result.failure(AppException(errorCode: 'INVALID_FILE', message: validationError));
    }

    AppLogger.info('Uploading attachment "$fileName" for service "$serviceKey" module "$moduleKey"...');

    return _apiClient.post<AttachmentMetadata>(
      '/mobile/services/upload.php',
      data: {
        'service_key': serviceKey,
        'module_key': moduleKey,
        'record_id': recordId ?? '',
        'file_name': fileName,
        'mime_type': mimeType,
        'base64_data': base64Data,
      },
      parser: (data) => AttachmentMetadata.fromJson(data as Map<String, dynamic>),
    );
  }
}
