import '../logging/app_logger.dart';
import '../secure_storage/secure_storage_service.dart';

/// Enterprise Security Guard for Flutter Client
/// 
/// Invariants:
/// - Strictly validates deep-links against role authorization and URI format.
/// - Purges local secure storage and cached sessions on logout or revocation.
/// - Redacts sensitive tokens and credentials from UI error displays.
class SecurityGuard {
  final SecureStorageService _storage;

  const SecurityGuard(this._storage);

  /// Validates deep-link targets to prevent horizontal/vertical access bypass
  static bool validateDeepLink({
    required String uriString,
    required String userRole,
  }) {
    try {
      // Check path traversal pattern before/after URI parsing
      if (uriString.contains('/../') || uriString.contains('/..') || uriString.contains('\\..')) {
        AppLogger.warning('Deep link rejected due to path traversal pattern: $uriString');
        return false;
      }

      final uri = Uri.parse(uriString);
      final path = uri.path.toLowerCase();

      // Ensure allowed scheme
      if (uri.hasScheme && uri.scheme != 'necner' && uri.scheme != 'https' && uri.scheme != 'http') {
        AppLogger.warning('Rejected deep link with unpermitted scheme: ${uri.scheme}');
        return false;
      }

      // Check consecutive slashes in the path component only
      if (path.contains('//')) {
        AppLogger.warning('Deep link rejected due to consecutive slashes: $path');
        return false;
      }

      // Customer role cannot access admin consoles or diagnostics
      final isCustomer = userRole.toLowerCase() == 'customer' || userRole.toLowerCase() == 'user';
      if (isCustomer) {
        if (path.contains('/admin') || path.contains('/diagnostics') || path.contains('/merchant/settings')) {
          AppLogger.warning('Customer blocked from administrative deep link: $path');
          return false;
        }
      }

      return true;
    } catch (e) {
      AppLogger.error('Failed to parse deep link URI: $uriString', error: e);
      return false;
    }
  }

  /// Scrubs sensitive details (passwords, tokens, PANs) from user-facing error messages
  static String sanitizeUserMessage(String message) {
    var clean = message;
    clean = clean.replaceAll(RegExp(r'Bearer\s+[A-Za-z0-9\-_\.~\+\/=]+', caseSensitive: false), 'Bearer [REDACTED]');
    clean = clean.replaceAll(RegExp(r'"password"\s*:\s*"[^"]*"', caseSensitive: false), '"password":"[REDACTED]"');
    clean = clean.replaceAll(RegExp(r'\b(?:\d{4}[ -]?){3}\d{4}\b'), '[REDACTED_CARD]');
    clean = clean.replaceAll(RegExp(r'SQLSTATE\[.*?\]', caseSensitive: false), 'Database Operation Error');
    return clean;
  }

  /// Executes complete cryptographic session purge on user logout or session revocation
  Future<void> purgeClientSession() async {
    try {
      await _storage.clearSession();
      await _storage.wipeAll();
      AppLogger.info('SecurityGuard: Client tokens and session credentials successfully purged.');
    } catch (e) {
      AppLogger.error('SecurityGuard: Error while purging client session', error: e);
    }
  }
}
