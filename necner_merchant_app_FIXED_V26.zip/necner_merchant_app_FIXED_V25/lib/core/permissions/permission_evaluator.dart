import '../../data/models/service_models.dart';
import '../actions/action_definition.dart';

/// Single, production-grade Permission Evaluator for Merchant Services
/// Complies with Phase 5 Section 14.
class PermissionEvaluator {
  final List<String> _userPermissions;
  final List<String> _assignedServices;

  const PermissionEvaluator({
    required List<String> userPermissions,
    required List<String> assignedServices,
  })  : _userPermissions = userPermissions,
        _assignedServices = assignedServices;

  /// Checks if a service is assigned to this merchant tenant
  bool isServiceAssigned(String serviceKey) {
    return _assignedServices.contains(serviceKey.toLowerCase());
  }

  /// Checks if user has a raw permission string or wildcard
  bool hasPermission(String requiredPermission) {
    if (requiredPermission.isEmpty || requiredPermission == 'none') return true;
    if (_userPermissions.contains('*') || _userPermissions.contains('all')) return true;

    // Direct match
    if (_userPermissions.contains(requiredPermission)) return true;

    // Domain wildcard check e.g. "orders.*" matches "orders.write"
    final parts = requiredPermission.split('.');
    if (parts.length > 1) {
      final domainWildcard = '${parts[0]}.*';
      if (_userPermissions.contains(domainWildcard)) return true;
    }

    return false;
  }

  /// Evaluates read access for a service module
  bool canViewModule({
    required String serviceKey,
    required ServiceManifest? manifest,
    required ServiceModule module,
  }) {
    if (!isServiceAssigned(serviceKey)) return false;
    if (module.capability == CapabilityState.disabled) return false;

    // Verify all required read permissions
    for (final perm in module.permissionsRequired) {
      if (perm.endsWith('.read') || perm.endsWith('.view') || !perm.contains('.')) {
        if (!hasPermission(perm)) return false;
      }
    }
    return true;
  }

  /// Evaluates create / write access for a service module
  bool canCreateInModule({
    required String serviceKey,
    required ServiceModule module,
  }) {
    if (!isServiceAssigned(serviceKey)) return false;
    if (module.capability != CapabilityState.available) return false;

    for (final perm in module.permissionsRequired) {
      if (perm.endsWith('.write') || perm.endsWith('.create') || perm.endsWith('.manage')) {
        if (!hasPermission(perm)) return false;
      }
    }
    return true;
  }

  /// Evaluates edit access for a service module
  bool canEditInModule({
    required String serviceKey,
    required ServiceModule module,
  }) {
    if (!isServiceAssigned(serviceKey)) return false;
    if (module.capability != CapabilityState.available) return false;

    for (final perm in module.permissionsRequired) {
      if (perm.endsWith('.write') || perm.endsWith('.edit') || perm.endsWith('.manage')) {
        if (!hasPermission(perm)) return false;
      }
    }
    return true;
  }

  /// Evaluates delete access for a service module
  bool canDeleteInModule({
    required String serviceKey,
    required ServiceModule module,
  }) {
    if (!isServiceAssigned(serviceKey)) return false;
    if (module.capability != CapabilityState.available) return false;

    for (final perm in module.permissionsRequired) {
      if (perm.endsWith('.delete') || perm.endsWith('.manage')) {
        if (!hasPermission(perm)) return false;
      }
    }
    return false; // delete is restrictive by default unless explicit permission
  }

  /// Evaluates whether an action is executable
  bool canExecute(ActionDefinition action) {
    return getActionStatus(action) == ActionStatus.available;
  }

  /// Resolves the comprehensive status of an action
  ActionStatus getActionStatus(ActionDefinition action) {
    // 1. Service assignment check
    if (!isServiceAssigned(action.serviceKey)) {
      return ActionStatus.disabled;
    }

    // 2. Permission check
    if (!hasPermission(action.permissionRequired)) {
      return ActionStatus.forbidden;
    }

    // 3. Known unsupported actions check
    if (action.actionKey == 'unsupported_action' || action.actionKey == 'not_implemented') {
      return ActionStatus.notImplemented;
    }

    return ActionStatus.available;
  }
}
