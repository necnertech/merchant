/// Application-wide constants
class AppConstants {
  const AppConstants._();

  static const String appName = 'Necner Merchant';
  static const String defaultAppVersion = '1.0.0';

  // Secure Storage Keys
  static const String keyAccessToken = 'necner_access_token';
  static const String keyRefreshToken = 'necner_refresh_token';
  static const String keyAccessTokenExpiresAt = 'necner_token_expires_at';
  static const String keyDeviceId = 'necner_device_id';
  static const String keyLastBootstrapConfig = 'necner_cached_bootstrap';

  // Network Timeouts (Milliseconds)
  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 15);
  static const Duration sendTimeout = Duration(seconds: 15);

  // Fallback initial discovery endpoint origin (Can be overridden by build flavor or environment)
  static const String defaultBootstrapOrigin = String.fromEnvironment(
    'BOOTSTRAP_ORIGIN',
    defaultValue: 'https://udidesign.in',
  );
}
