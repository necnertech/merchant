/// Centralized API endpoint constants consumed by the Flutter application.
class ApiEndpoints {
  const ApiEndpoints._();

  static const String bootstrap = '/mobile/config/bootstrap';
  static const String login = '/mobile/auth/login';
  static const String refresh = '/mobile/auth/refresh';
  static const String logout = '/mobile/auth/logout';
  static const String me = '/mobile/auth/me';
  static const String merchantProfile = '/mobile/profile.php';
  static const String notificationPoll = '/mobile/notifications/poll.php';
  static const String videoCall = '/mobile/calls/video.php';
  static const String global = '/mobile/global.php';

  static const String services = '/mobile/services';
  static String serviceManifest(String serviceKey) => '/mobile/services/$serviceKey/manifest';
}
