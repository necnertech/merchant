import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';
import '../logging/app_logger.dart';

/// Hardware-backed secure storage service.
/// Uses Android Keystore (EncryptedSharedPreferences) and iOS Keychain (kSecAttrAccessibleAfterFirstUnlock).
/// Invariants:
/// - Never persists passwords.
/// - Never logs sensitive values.
/// - Provides atomic wipe on logout.
class SecureStorageService {
  final FlutterSecureStorage _storage;

  SecureStorageService({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(
                encryptedSharedPreferences: true,
                resetOnError: true,
              ),
              iOptions: IOSOptions(
                accessibility: KeychainAccessibility.first_unlock,
              ),
            );

  // --- Token Operations ---

  Future<void> saveTokens({
    required String accessToken,
    required String refreshToken,
    required DateTime expiresAt,
  }) async {
    await _storage.write(key: AppConstants.keyAccessToken, value: accessToken);
    await _storage.write(key: AppConstants.keyRefreshToken, value: refreshToken);
    await _storage.write(
      key: AppConstants.keyAccessTokenExpiresAt,
      value: expiresAt.toIso8601String(),
    );
    AppLogger.info('Tokens saved securely in hardware-backed storage.');
  }

  Future<String?> getAccessToken() async {
    return _storage.read(key: AppConstants.keyAccessToken);
  }

  Future<String?> getRefreshToken() async {
    return _storage.read(key: AppConstants.keyRefreshToken);
  }

  Future<DateTime?> getTokenExpiresAt() async {
    final raw = await _storage.read(key: AppConstants.keyAccessTokenExpiresAt);
    if (raw == null) return null;
    return DateTime.tryParse(raw);
  }

  Future<bool> hasValidToken() async {
    final token = await getAccessToken();
    if (token == null || token.isEmpty) return false;
    final expiry = await getTokenExpiresAt();
    if (expiry == null) return false;
    // Buffer by 30 seconds to prevent race conditions
    return DateTime.now().isBefore(expiry.subtract(const Duration(seconds: 30)));
  }


  // --- Dynamic Bootstrap Configuration ---

  Future<void> saveBootstrapConfig(Map<String, dynamic> config) async {
    await _storage.write(
      key: AppConstants.keyLastBootstrapConfig,
      value: jsonEncode(config),
    );
    AppLogger.info('Last-known-good bootstrap configuration saved securely.');
  }

  Future<Map<String, dynamic>?> getBootstrapConfig() async {
    final raw = await _storage.read(key: AppConstants.keyLastBootstrapConfig);
    if (raw == null || raw.trim().isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } catch (_) {
      await _storage.delete(key: AppConstants.keyLastBootstrapConfig);
    }
    return null;
  }

  // --- Device ID ---

  Future<void> saveDeviceId(String deviceId) async {
    await _storage.write(key: AppConstants.keyDeviceId, value: deviceId);
  }

  Future<String?> getDeviceId() async {
    return _storage.read(key: AppConstants.keyDeviceId);
  }

  // --- Purge Operations ---

  /// Securely purges all authenticated credentials upon logout or session revocation.
  Future<void> clearSession() async {
    await _storage.delete(key: AppConstants.keyAccessToken);
    await _storage.delete(key: AppConstants.keyRefreshToken);
    await _storage.delete(key: AppConstants.keyAccessTokenExpiresAt);
    AppLogger.info('Secure session cleared completely.');
  }

  Future<void> wipeAll() async {
    await _storage.deleteAll();
    AppLogger.info('All secure storage purged.');
  }
}
