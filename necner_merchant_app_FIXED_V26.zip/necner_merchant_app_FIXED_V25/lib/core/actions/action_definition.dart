import '../../data/models/module_schema_models.dart' show FieldDefinition;

enum ActionStatus {
  available,
  disabled,
  readOnly,
  notImplemented,
  forbidden,
}

/// Generic Action Definition for Merchant Service Operations
class ActionDefinition {
  final String actionKey;
  final String title;
  final String description;
  final String serviceKey;
  final String moduleKey;
  final String entityType;
  final String permissionRequired;
  final String httpMethod;
  final String endpoint;
  final List<FieldDefinition> fields;
  final bool requiresConfirmation;
  final String? confirmationMessage;
  final bool requiresIdempotency;
  final bool optimisticPolicy;
  final String successBehavior; // 'refresh_list' | 'navigate_back' | 'update_card'
  final String failureBehavior; // 'retry_prompt' | 'show_error'

  const ActionDefinition({
    required this.actionKey,
    required this.title,
    required this.description,
    required this.serviceKey,
    required this.moduleKey,
    required this.entityType,
    required this.permissionRequired,
    this.httpMethod = 'POST',
    this.endpoint = '/mobile/services/action.php',
    this.fields = const [],
    this.requiresConfirmation = false,
    this.confirmationMessage,
    this.requiresIdempotency = true,
    this.optimisticPolicy = false,
    this.successBehavior = 'refresh_list',
    this.failureBehavior = 'show_error',
  });

  factory ActionDefinition.fromJson(Map<String, dynamic> json) {
    List<FieldDefinition> fieldList = [];
    if (json['fields'] is List) {
      fieldList = (json['fields'] as List)
          .map((f) => FieldDefinition.fromJson(f as Map<String, dynamic>))
          .toList();
    }

    return ActionDefinition(
      actionKey: json['action_key']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Action',
      description: json['description']?.toString() ?? '',
      serviceKey: json['service_key']?.toString() ?? 'general',
      moduleKey: json['module_key']?.toString() ?? 'general',
      entityType: json['entity_type']?.toString() ?? 'record',
      permissionRequired: json['permission_required']?.toString() ?? 'read',
      httpMethod: json['http_method']?.toString().toUpperCase() ?? 'POST',
      endpoint: json['endpoint']?.toString() ?? '/mobile/services/action.php',
      fields: fieldList,
      requiresConfirmation: json['requires_confirmation'] == true,
      confirmationMessage: json['confirmation_message']?.toString(),
      requiresIdempotency: json['requires_idempotency'] != false,
      optimisticPolicy: json['optimistic_policy'] == true,
      successBehavior: json['success_behavior']?.toString() ?? 'refresh_list',
      failureBehavior: json['failure_behavior']?.toString() ?? 'show_error',
    );
  }

  Map<String, dynamic> toJson() => {
    'action_key': actionKey,
    'title': title,
    'description': description,
    'service_key': serviceKey,
    'module_key': moduleKey,
    'entity_type': entityType,
    'permission_required': permissionRequired,
    'http_method': httpMethod,
    'endpoint': endpoint,
    'requires_confirmation': requiresConfirmation,
    'confirmation_message': confirmationMessage,
    'requires_idempotency': requiresIdempotency,
    'optimistic_policy': optimisticPolicy,
    'success_behavior': successBehavior,
    'failure_behavior': failureBehavior,
  };
}
