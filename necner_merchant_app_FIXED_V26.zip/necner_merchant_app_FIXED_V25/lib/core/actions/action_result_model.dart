/// Standardized Service Action Result Model
/// Complies with Phase 5 Section 13 specification.
library;

class ServiceActionResult {
  final bool success;
  final String message;
  final Map<String, dynamic>? data;
  final String? entity;
  final String? entityId;
  final String? serviceKey;
  final String? actionKey;
  final String? status;
  final String? reference;
  final String? activityEventId;
  final String? notificationEventId;
  final bool requiresRefresh;

  const ServiceActionResult({
    required this.success,
    required this.message,
    this.data,
    this.entity,
    this.entityId,
    this.serviceKey,
    this.actionKey,
    this.status,
    this.reference,
    this.activityEventId,
    this.notificationEventId,
    this.requiresRefresh = true,
  });

  factory ServiceActionResult.fromJson(Map<String, dynamic> json, {String? defaultActionKey, String? defaultServiceKey}) {
    final isSuccess = json['success'] == true;
    final dataMap = json['data'] is Map ? Map<String, dynamic>.from(json['data'] as Map) : null;

    final actKey = dataMap?['action_key']?.toString() ?? json['action_key']?.toString() ?? defaultActionKey;
    final sKey = dataMap?['service_key']?.toString() ?? json['service_key']?.toString() ?? defaultServiceKey;
    final recId = dataMap?['record_id']?.toString() ?? json['record_id']?.toString() ?? json['entity_id']?.toString();
    final stat = dataMap?['status']?.toString() ?? json['status']?.toString() ?? (isSuccess ? 'completed' : 'failed');
    final ref = dataMap?['reference']?.toString() ?? json['reference']?.toString() ?? 'REF-$recId';

    return ServiceActionResult(
      success: isSuccess,
      message: json['message']?.toString() ?? (isSuccess ? 'Action completed successfully.' : 'Action failed.'),
      data: dataMap,
      entity: json['entity']?.toString() ?? json['entity_type']?.toString(),
      entityId: recId,
      serviceKey: sKey,
      actionKey: actKey,
      status: stat,
      reference: ref,
      activityEventId: json['activity_event_id']?.toString(),
      notificationEventId: json['notification_event_id']?.toString(),
      requiresRefresh: json['requires_refresh'] != false,
    );
  }

  factory ServiceActionResult.failure(String errorMessage, {String? actionKey, String? serviceKey}) {
    return ServiceActionResult(
      success: false,
      message: errorMessage,
      actionKey: actionKey,
      serviceKey: serviceKey,
      status: 'failed',
      requiresRefresh: false,
    );
  }

  Map<String, dynamic> toJson() => {
    'success': success,
    'message': message,
    'data': data,
    'entity': entity,
    'entity_id': entityId,
    'service_key': serviceKey,
    'action_key': actionKey,
    'status': status,
    'reference': reference,
    'activity_event_id': activityEventId,
    'notification_event_id': notificationEventId,
    'requires_refresh': requiresRefresh,
  };
}
