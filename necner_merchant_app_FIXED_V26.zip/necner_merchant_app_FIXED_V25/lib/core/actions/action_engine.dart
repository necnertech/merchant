import 'package:flutter/material.dart';
import '../logging/app_logger.dart';
import '../network/api_client.dart';
import '../network/idempotency_service.dart';
import '../permissions/permission_evaluator.dart';
import '../realtime/realtime_service.dart';
import 'action_definition.dart';
import 'action_result_model.dart';

/// Generic Merchant Service Action Engine
/// Orchestrates validation, permission check, idempotency, execution, and activity dispatch.
class ActionEngine {
  final ApiClient _apiClient;
  final IdempotencyService _idempotencyService;
  final RealtimeService _realtimeService;

  ActionEngine({
    required ApiClient apiClient,
    required IdempotencyService idempotencyService,
    required RealtimeService realtimeService,
  })  : _apiClient = apiClient,
        _idempotencyService = idempotencyService,
        _realtimeService = realtimeService;

  /// Executes a service action through the production pipeline
  Future<ServiceActionResult> execute({
    required ActionDefinition action,
    required Map<String, dynamic> payload,
    required PermissionEvaluator permissionEvaluator,
    BuildContext? context,
    VoidCallback? onOptimisticUpdate,
    String? existingIdempotencyKey,
  }) async {
    // 1. Permission check
    final status = permissionEvaluator.getActionStatus(action);
    if (status == ActionStatus.forbidden) {
      AppLogger.warning('Action forbidden: ${action.actionKey}');
      return ServiceActionResult.failure(
        'Permission denied for action: ${action.title}',
        actionKey: action.actionKey,
        serviceKey: action.serviceKey,
      );
    }

    if (status == ActionStatus.disabled) {
      return ServiceActionResult.failure(
        'Service "${action.serviceKey}" is not assigned to this merchant.',
        actionKey: action.actionKey,
        serviceKey: action.serviceKey,
      );
    }

    if (status == ActionStatus.notImplemented) {
      return ServiceActionResult.failure(
        'Action "${action.title}" is not implemented on the mobile gateway.',
        actionKey: action.actionKey,
        serviceKey: action.serviceKey,
      );
    }

    // 2. Prompt confirmation dialog if required
    if (action.requiresConfirmation && context != null && context.mounted) {
      final confirmed = await _showConfirmationDialog(
        context: context,
        action: action,
        message: action.confirmationMessage ?? 'Are you sure you want to proceed with "${action.title}"?',
      );
      if (!confirmed) {
        return ServiceActionResult.failure('Action cancelled by user.', actionKey: action.actionKey, serviceKey: action.serviceKey);
      }
    }

    // 3. Optimistic UI callback
    if (action.optimisticPolicy && onOptimisticUpdate != null) {
      onOptimisticUpdate();
    }

    // 4. Generate or reuse Idempotency Key
    final idempKey = existingIdempotencyKey ??
        _idempotencyService.generateKey(action.actionKey, entityId: payload['id']?.toString());

    // 5. Execute with duplicate-submit protection
    return _idempotencyService.executeSafely(
      idempotencyKey: idempKey,
      operation: () async {
        AppLogger.info('Executing action "${action.actionKey}" [Idempotency: $idempKey]');

        final result = await _apiClient.post<Map<String, dynamic>>(
          action.endpoint,
          data: {
            'service_key': action.serviceKey,
            'action_key': action.actionKey,
            'data': payload,
            'idempotency_key': idempKey,
          },
          parser: (data) => data is Map<String, dynamic> ? data : {},
        );

        return result.when(
          success: (resData) {
            final actionResult = ServiceActionResult.fromJson(
              {'success': true, 'data': resData},
              defaultActionKey: action.actionKey,
              defaultServiceKey: action.serviceKey,
            );

            // 6. Synchronize Realtime Activity
            _realtimeService.dispatchEvent('activity.created', {
              'service_key': action.serviceKey,
              'action_key': action.actionKey,
              'title': action.title,
              'entity_id': actionResult.entityId,
              'timestamp': DateTime.now().toIso8601String(),
            });

            // 7. Synchronize entity-specific events
            if (action.entityType == 'order') {
              _realtimeService.dispatchEvent('order.updated', {
                'order_id': actionResult.entityId,
                'status': actionResult.status,
              });
            } else if (action.entityType == 'appointment') {
              _realtimeService.dispatchEvent('appointment.updated', {
                'appointment_id': actionResult.entityId,
                'status': actionResult.status,
              });
            } else if (action.entityType == 'payment') {
              _realtimeService.dispatchEvent('payment.received', {
                'reference': actionResult.reference,
                'status': actionResult.status,
              });
            }

            return actionResult;
          },
          failure: (err) {
            AppLogger.error('Action "${action.actionKey}" failed: ${err.message}');
            return ServiceActionResult.failure(
              err.message,
              actionKey: action.actionKey,
              serviceKey: action.serviceKey,
            );
          },
        );
      },
    );
  }

  Future<bool> _showConfirmationDialog({
    required BuildContext context,
    required ActionDefinition action,
    required String message,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(action.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF075E54)),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Confirm', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    return result ?? false;
  }
}
