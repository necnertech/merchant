import 'dart:async';
import '../actions/action_result_model.dart';
import '../logging/app_logger.dart';

/// Idempotency & Transaction Safety Service
/// Prevents accidental double writes (e.g. double charging, double confirming).
class IdempotencyService {
  final Map<String, Completer<ServiceActionResult>> _inFlightActions = {};
  final Map<String, ServiceActionResult> _cachedResults = {};

  /// Generates a unique, structured idempotency key
  String generateKey(String actionKey, {String? entityId}) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final randomHex = (100000 + (DateTime.now().microsecond * 899)).toRadixString(16);
    final entityPart = entityId != null ? '_$entityId' : '';
    return 'idemp_$actionKey${entityPart}_${timestamp}_$randomHex';
  }

  /// Checks if an action is currently executing
  bool isInFlight(String idempotencyKey) {
    return _inFlightActions.containsKey(idempotencyKey);
  }

  /// Executes an operation with duplicate submission protection and idempotency caching
  Future<ServiceActionResult> executeSafely({
    required String idempotencyKey,
    required Future<ServiceActionResult> Function() operation,
  }) async {
    // 1. Check if identical idempotency key was already completed
    if (_cachedResults.containsKey(idempotencyKey)) {
      AppLogger.info('Returning cached result for idempotency key: $idempotencyKey');
      return _cachedResults[idempotencyKey]!;
    }

    // 2. Prevent concurrent duplicate submission
    if (_inFlightActions.containsKey(idempotencyKey)) {
      AppLogger.warning('Duplicate submission detected for key: $idempotencyKey. Awaiting in-flight response.');
      return _inFlightActions[idempotencyKey]!.future;
    }

    // 3. Register in-flight completer
    final completer = Completer<ServiceActionResult>();
    _inFlightActions[idempotencyKey] = completer;

    try {
      final result = await operation();

      if (result.success) {
        _cachedResults[idempotencyKey] = result;
      }

      completer.complete(result);
      return result;
    } catch (e) {
      final fail = ServiceActionResult.failure('Action execution failed: $e');
      completer.complete(fail);
      return fail;
    } finally {
      _inFlightActions.remove(idempotencyKey);
    }
  }

  /// Clears cache (e.g. on session logout)
  void clear() {
    _inFlightActions.clear();
    _cachedResults.clear();
  }
}
