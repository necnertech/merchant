import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import '../constants/api_endpoints.dart';
import '../logging/app_logger.dart';
import '../secure_storage/secure_storage_service.dart';

/// Authentication interceptor for the merchant API.
/// Attaches the access token to both Authorization and X-Authorization.
/// The current backend uses long-lived bearer sessions and does not expose
/// a usable refresh endpoint, so 401 responses are handled without a
/// refresh loop.
class AuthInterceptor extends QueuedInterceptor {
  final SecureStorageService _storage;
  final VoidCallback _onSessionExpired;

  AuthInterceptor({
    required SecureStorageService storage,
    required VoidCallback onSessionExpired,
  }) : _storage = storage,
        _onSessionExpired = onSessionExpired;

  @override
  Future<void> onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    // Inject Authorization header if token is present and not explicitly skipped
    final skipAuth = options.extra['skipAuth'] == true;
    if (!skipAuth) {
      final token = await _storage.getAccessToken();
      if (token != null && token.isNotEmpty) {
        options.headers['Authorization'] = 'Bearer $token';
        // Hostinger/Apache/LiteSpeed can strip the standard Authorization
        // header before PHP receives the request. Keep a fallback header too.
        options.headers['X-Authorization'] = 'Bearer $token';
        AppLogger.info('Auth header attached to ${options.method} ${options.path}.');
      }
    }
    if (skipAuth) {
      AppLogger.info('Auth header skipped for ${options.method} ${options.path}.');
    }
    handler.next(options);
  }

  @override
  Future<void> onError(
    DioException err,
    ErrorInterceptorHandler handler,
  ) async {
    final response = err.response;
    final requestOptions = err.requestOptions;
    final is401 = response?.statusCode == 401;
    final isLoginEndpoint = _isEndpoint(requestOptions.path, ApiEndpoints.login);
    final isRefreshEndpoint = _isEndpoint(requestOptions.path, ApiEndpoints.refresh);
    final isMeEndpoint = _isEndpoint(requestOptions.path, ApiEndpoints.me);

    if (!is401 || isLoginEndpoint || isRefreshEndpoint) {
      return handler.next(err);
    }

    // The current Hostinger merchant backend intentionally does NOT support
    // refresh tokens (it returns REFRESH_NOT_SUPPORTED). Never turn an
    // ordinary API 401 into a refresh loop or a false "session expired"
    // screen.
    final errorCode = response?.data is Map
        ? (response?.data['error_code']?.toString() ?? '')
        : '';
    final isAuthenticationFailure =
        errorCode == 'AUTH_REQUIRED' ||
        errorCode == 'INVALID_TOKEN' ||
        errorCode == 'TOKEN_EXPIRED' ||
        errorCode == 'ACCOUNT_INACTIVE';

    // /auth/me is the authoritative session validation endpoint. When it
    // fails, clear the local credentials and return to login. Other 401s are
    // passed through to their repository/controller so a feature endpoint
    // cannot unexpectedly log the merchant out.
    if (isMeEndpoint || isAuthenticationFailure) {
      await _storage.clearSession();
      _onSessionExpired();
    }

    return handler.next(err);
  }

  bool _isEndpoint(String requestPath, String endpoint) {
    final request = requestPath.trim();
    final target = endpoint.trim();
    if (request == target) return true;
    // ApiClient normalizes /mobile/... to /... when the base URL already
    // contains /mobile, so compare both forms.
    final normalizedTarget = target.startsWith('/mobile/')
        ? target.substring('/mobile'.length)
        : target;
    return request == normalizedTarget || request.endsWith(normalizedTarget);
  }

}
