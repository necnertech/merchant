import 'dart:math';
import 'package:flutter/material.dart';

/// Accessibility and WCAG 2.1 AA Compliance Guard
/// 
/// Validates touch targets, contrast ratios, dynamic scaling, and semantic trees
/// across WhatsApp Business-inspired Flutter screens.
class AccessibilityGuard {
  const AccessibilityGuard._();

  static const double minTouchTargetSize = 48.0; // Material & Apple HIG standard
  static const double wcagNormalContrastThreshold = 4.5;
  static const double wcagLargeContrastThreshold = 3.0;
  static const double maxTestedFontScale = 2.0;

  /// Verifies whether an interactive component meets the 48x48dp minimum touch target
  static bool meetsMinimumTouchTarget(Size size) {
    return size.width >= minTouchTargetSize && size.height >= minTouchTargetSize;
  }

  /// Calculates relative luminance for WCAG contrast calculation
  static double getRelativeLuminance(Color color) {
    double transformComponent(double val) {
      if (val <= 0.03928) {
        return val / 12.92;
      }
      return pow((val + 0.055) / 1.055, 2.4).toDouble();
    }

    final r = transformComponent(color.r);
    final g = transformComponent(color.g);
    final b = transformComponent(color.b);

    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  /// Calculates the contrast ratio between two colors according to WCAG 2.1
  static double calculateContrastRatio(Color foreground, Color background) {
    final l1 = getRelativeLuminance(foreground);
    final l2 = getRelativeLuminance(background);

    final lighter = max(l1, l2);
    final darker = min(l1, l2);

    return (lighter + 0.05) / (darker + 0.05);
  }

  /// Verifies if contrast ratio meets WCAG AA standards (4.5:1 normal, 3.0:1 large)
  static bool isContrastCompliant(Color foreground, Color background, {bool isLargeText = false}) {
    final ratio = calculateContrastRatio(foreground, background);
    final threshold = isLargeText ? wcagLargeContrastThreshold : wcagNormalContrastThreshold;
    return ratio >= threshold;
  }

  /// Verifies whether a given font scale factor is within tested bounds
  static bool isFontScaleSupported(double textScaleFactor) {
    return textScaleFactor >= 0.85 && textScaleFactor <= maxTestedFontScale;
  }

  /// Verifies that an interactive action has a meaningful semantic label
  static bool hasValidSemanticLabel(String? label) {
    if (label == null) return false;
    final trimmed = label.trim();
    return trimmed.isNotEmpty && trimmed.length >= 2;
  }
}
