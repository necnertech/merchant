import 'package:flutter/foundation.dart';
import '../secure_storage/secure_storage_service.dart';

/// Privacy-respecting device identifier service.
/// Generates a randomized, persistent UUID per installation stored in secure storage.
/// Does NOT collect sensitive MAC addresses, IMEI, or intrusive hardware fingerprints.
class DeviceService {
  final SecureStorageService _storage;

  DeviceService(this._storage);

  Future<String> getDeviceId() async {
    var deviceId = await _storage.getDeviceId();
    if (deviceId != null && deviceId.isNotEmpty) {
      return deviceId;
    }

    // Generate privacy-safe random installation ID
    final randomPart = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
    final randomHex = (100000 + (DateTime.now().millisecond * 899)).toString();
    deviceId = 'dev_${getPlatformName()}_$randomPart$randomHex';

    await _storage.saveDeviceId(deviceId);
    return deviceId;
  }

  String getPlatformName() {
    if (kIsWeb) return 'web';
    if (defaultTargetPlatform == TargetPlatform.android) return 'android';
    if (defaultTargetPlatform == TargetPlatform.iOS) return 'ios';
    return 'unknown';
  }
}
