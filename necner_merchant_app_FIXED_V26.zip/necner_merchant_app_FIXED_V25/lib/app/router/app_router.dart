import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../core/secure_storage/secure_storage_service.dart';
import '../../data/models/service_models.dart';
import '../config/app_config.dart';
import '../../features/auth/login/login_screen.dart';
import '../../features/auth/profile/profile_screen.dart';
import '../../features/auth/session/auth_controller.dart';
import '../../features/bootstrap/presentation/config_error_screen.dart';
import '../../features/bootstrap/presentation/force_update_screen.dart';
import '../../features/bootstrap/presentation/maintenance_screen.dart';
import '../../features/bootstrap/presentation/splash_screen.dart';
import '../../features/bootstrap/state/bootstrap_controller.dart';
import '../../features/chat/presentation/chat_detail_screen.dart';
import '../../features/chat/presentation/chats_screen.dart';
import '../../features/customer/presentation/customer_home_screen.dart';
import '../../features/notifications/presentation/notifications_screen.dart';
import '../../features/services/engine/dynamic_module_registry.dart';
import '../../features/services/engine/service_adapter.dart';
import '../../features/services/presentation/generic_module_list_screen.dart';
import '../../features/services/presentation/service_detail_screen.dart';
import '../../features/services/presentation/services_screen.dart';
import '../../features/services/presentation/common_settings_screen.dart';
import '../../features/whatsapp/presentation/whatsapp_hub_screen.dart';
import '../../features/global/presentation/global_tools_screen.dart';
import '../../features/shell/presentation/main_shell_screen.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>();

GoRouter createAppRouter({
  required AuthController authController,
  required BootstrapController bootstrapController,
}) {
  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/splash',
    refreshListenable: Listenable.merge([authController, bootstrapController]),
    redirect: (BuildContext context, GoRouterState state) {
      final currentLoc = state.matchedLocation;

      // 1. If bootstrap is in progress or on startup screens, allow
      if (currentLoc == '/splash' ||
          currentLoc == '/maintenance' ||
          currentLoc == '/force-update' ||
          currentLoc == '/config-error') {
        return null;
      }

      // 2. Intercept Maintenance Mode
      if (bootstrapController.status == BootstrapStatus.maintenance) {
        return '/maintenance';
      }

      // 3. Intercept Force Update
      if (bootstrapController.status == BootstrapStatus.forceUpdate) {
        return '/force-update';
      }

      // 4. Intercept Configuration Error
      if (bootstrapController.status == BootstrapStatus.error) {
        return '/config-error';
      }

      // 5. Auth Redirect Guards
      final isAuthenticated = authController.isAuthenticated;
      final isLoggingIn = currentLoc == '/login';

      if (!isAuthenticated && !isLoggingIn) {
        return '/login';
      }

      if (isAuthenticated && isLoggingIn) {
        return '/services';
      }

      return null;
    },
    routes: [
      // Startup Routes
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/maintenance',
        builder: (context, state) => const MaintenanceScreen(),
      ),
      GoRoute(
        path: '/force-update',
        builder: (context, state) => const ForceUpdateScreen(),
      ),
      GoRoute(
        path: '/config-error',
        builder: (context, state) => const ConfigErrorScreen(),
      ),

      // Auth Route
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginScreen(),
      ),

      // Customer Portal Route
      GoRoute(
        path: '/customer',
        builder: (context, state) => const CustomerHomeScreen(),
      ),

      GoRoute(
        path: '/tools',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const GlobalToolsScreen(),
      ),
      GoRoute(
        path: '/settings',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const CommonSettingsScreen(),
      ),

      GoRoute(
        path: '/whatsapp',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const WhatsAppHubScreen(),
      ),

      // WhatsApp Business Main Navigation Shell (4 Branches)
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) {
          return MainShellScreen(navigationShell: navigationShell);
        },
        branches: [
          // Branch 1: Chats & Interactive Threads
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/chats',
                builder: (context, state) => const ChatsScreen(),
                routes: [
                  GoRoute(
                    path: ':chat_id',
                    parentNavigatorKey: _rootNavigatorKey,
                    builder: (context, state) {
                      final chatId = state.pathParameters['chat_id'] ?? '1';
                      return ChatDetailScreen(chatId: chatId);
                    },
                  ),
                ],
              ),
            ],
          ),

          // Branch 2: Services, Dashboards & Dynamic Modules
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/notifications',
                builder: (context, state) => const NotificationsScreen(),
              ),
            ],
          ),

          // Branch 4: Profile & Settings
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/services',
                builder: (context, state) => const ServicesScreen(),
                routes: [
                  GoRoute(
                    path: ':service_key',
                    builder: (context, state) {
                      final key = state.pathParameters['service_key'] ?? '';
                      return ServiceDetailScreen(serviceKey: key);
                    },
                    routes: [
                      GoRoute(
                        path: 'modules/:module_key',
                        parentNavigatorKey: _rootNavigatorKey,
                        builder: (context, state) {
                          final serviceKey = state.pathParameters['service_key'] ?? '';
                          final moduleKey = state.pathParameters['module_key'] ?? '';
                          final extra = state.extra as Map<String, dynamic>?;

                          MerchantServiceAdapter adapter;
                          if (extra != null && extra['adapter'] is MerchantServiceAdapter) {
                            adapter = extra['adapter'] as MerchantServiceAdapter;
                          } else {
                            final config = context.read<AppConfig>();
                            final storage = SecureStorageService();
                            final apiClient = ApiClient(config: config, storage: storage, onSessionExpired: () {});
                            adapter = ServiceAdapterRegistry(apiClient).getAdapter(serviceKey);
                          }

                          final module = extra?['module'] as ServiceModule?;
                          final title = module?.title ?? moduleKey.toUpperCase();
                          final isReadOnly = module?.capability == CapabilityState.readOnly;

                          return GenericModuleListScreen(
                            adapter: adapter,
                            moduleKey: moduleKey,
                            moduleTitle: title,
                            isReadOnly: isReadOnly,
                            actions: module?.actions ?? const [],
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),

          // Branch 3: Alerts / Notifications
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/profile',
                builder: (context, state) => const ProfileScreen(),
                routes: [
                  GoRoute(
                    path: 'settings',
                    parentNavigatorKey: _rootNavigatorKey,
                    builder: (context, state) => const CommonSettingsScreen(profileOnly: true),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    ],
  );
}
