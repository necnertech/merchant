import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_constants.dart';
import 'router/app_router.dart';
import 'theme/app_theme.dart';
import '../features/auth/session/auth_controller.dart';
import '../features/bootstrap/state/bootstrap_controller.dart';

class NecnerMerchantApp extends StatefulWidget {
  const NecnerMerchantApp({super.key});

  @override
  State<NecnerMerchantApp> createState() => _NecnerMerchantAppState();
}

class _NecnerMerchantAppState extends State<NecnerMerchantApp> {
  late final GoRouter _router;

  @override
  void initState() {
    super.initState();
    final authCtrl = context.read<AuthController>();
    final bootstrapCtrl = context.read<BootstrapController>();

    _router = createAppRouter(
      authController: authCtrl,
      bootstrapController: bootstrapCtrl,
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      routerConfig: _router,
    );
  }
}
