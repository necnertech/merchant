import '../../core/constants/api_endpoints.dart';
import '../../core/logging/app_logger.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
import '../models/notification_models.dart';

class NotificationRepository {
  final ApiClient _apiClient;

  NotificationRepository(this._apiClient);

  /// Fetches notifications for the merchant tenant
  Future<Result<List<PushNotificationItem>>> getNotifications() async {
    return _apiClient.get<List<PushNotificationItem>>(
      '/mobile/notifications/index.php',
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list
              .map((item) => PushNotificationItem.fromJson(item as Map<String, dynamic>))
              .toList();
        }
        return [];
      },
    );
  }

  Future<Result<Map<String,dynamic>>> pollNewNotifications({int afterId=0}) => _apiClient.get<Map<String,dynamic>>(ApiEndpoints.notificationPoll,queryParameters:{'after_id':afterId,'limit':30},parser:(data)=>Map<String,dynamic>.from(data as Map));

  /// Marks a specific notification as read
  Future<Result<bool>> markAsRead(String notificationId) async {
    return _apiClient.post<bool>(
      '/mobile/notifications/read.php',
      data: {'id': notificationId},
      parser: (data) => true,
    );
  }

  /// Registers native FCM/APNs push token with backend gateway
  Future<Result<bool>> registerDeviceToken({
    required String deviceId,
    required String platform,
    required String pushToken,
    String? tokenProvider,
  }) async {
    AppLogger.info('Registering native push token for $platform ($deviceId)...');
    return _apiClient.post<bool>(
      '/mobile/device/register_token.php',
      data: {
        'device_id': deviceId,
        'platform': platform,
        'push_token': pushToken,
        'token_provider': tokenProvider ?? (platform == 'ios' ? 'apns' : 'fcm'),
      },
      parser: (data) => true,
    );
  }
}
