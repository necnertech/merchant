import 'package:dio/dio.dart';
import '../../core/constants/api_endpoints.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';

class MerchantProfileUpdate {
  final String businessName;
  final String? avatarUrl;
  final String email;
  final String phone;
  const MerchantProfileUpdate({required this.businessName,this.avatarUrl,required this.email,required this.phone});
  factory MerchantProfileUpdate.fromJson(Map<String,dynamic> json){
    final user=json['user'] is Map?Map<String,dynamic>.from(json['user']):<String,dynamic>{};
    final tenant=json['tenant'] is Map?Map<String,dynamic>.from(json['tenant']):<String,dynamic>{};
    return MerchantProfileUpdate(businessName:(tenant['business_name']??tenant['name']??'').toString(),avatarUrl:user['avatar_url']?.toString(),email:(user['email']??'').toString(),phone:(user['phone']??'').toString());
  }
}
class ProfileRepository {
  final ApiClient _apiClient; ProfileRepository(this._apiClient);
  Future<Result<MerchantProfileUpdate>> getProfile()=>_apiClient.get<MerchantProfileUpdate>(ApiEndpoints.merchantProfile,parser:(data)=>MerchantProfileUpdate.fromJson(Map<String,dynamic>.from(data as Map)));
  Future<Result<MerchantProfileUpdate>> updateProfile({String? businessName,String? logoPath}) async {
    final form=FormData();
    if(businessName!=null&&businessName.trim().isNotEmpty) form.fields.add(MapEntry('business_name',businessName.trim()));
    if(logoPath!=null&&logoPath.isNotEmpty) form.files.add(MapEntry('logo',await MultipartFile.fromFile(logoPath,filename:logoPath.split('/').last)));
    return _apiClient.post<MerchantProfileUpdate>(ApiEndpoints.merchantProfile,data:form,parser:(data)=>MerchantProfileUpdate.fromJson(Map<String,dynamic>.from(data as Map)));
  }
}
