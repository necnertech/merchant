import '../../core/constants/api_endpoints.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
import '../models/service_models.dart';

class ServiceRepository {
  final ApiClient _apiClient;

  ServiceRepository(this._apiClient);

  /// Discovers services actively assigned to the authenticated merchant tenant
  Future<Result<List<ServiceDiscoveryItem>>> getAssignedServices() async {
    return _apiClient.get<List<ServiceDiscoveryItem>>(
      ApiEndpoints.services,
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list
              .map((item) => ServiceDiscoveryItem.fromJson(item as Map<String, dynamic>))
              .toList();
        }
        return [];
      },
    );
  }

  /// Loads service manifest with explicit capabilities
  Future<Result<ServiceManifest>> getServiceManifest(String serviceKey) async {
    return _apiClient.get<ServiceManifest>(
      ApiEndpoints.serviceManifest(serviceKey),
      parser: (data) => ServiceManifest.fromJson(data as Map<String, dynamic>),
    );
  }
}
