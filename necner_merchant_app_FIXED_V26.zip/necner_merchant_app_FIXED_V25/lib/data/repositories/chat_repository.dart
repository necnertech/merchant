import '../../core/logging/app_logger.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
import '../models/chat_models.dart';

class ChatRepository {
  final ApiClient _apiClient;

  ChatRepository(this._apiClient);

  /// Fetches merchant conversation threads
  Future<Result<List<ConversationSummary>>> getConversations() async {
    return _apiClient.get<List<ConversationSummary>>(
      '/mobile/chat/index.php',
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list
              .map((item) => ConversationSummary.fromJson(item as Map<String, dynamic>))
              .toList();
        }
        return [];
      },
    );
  }

  /// Fetches message thread for a conversation
  Future<Result<List<ChatMessageItem>>> getMessages(String chatId) async {
    return _apiClient.get<List<ChatMessageItem>>(
      '/mobile/chat/messages.php',
      queryParameters: {'chat_id': chatId},
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list
              .map((item) => ChatMessageItem.fromJson(item as Map<String, dynamic>))
              .toList();
        }
        return [];
      },
    );
  }

  /// Dispatches an interactive message (text, voice, order, appointment, payment)
  Future<Result<ChatMessageItem>> sendMessage({
    required String chatId,
    required String type,
    required String content,
    Map<String, dynamic>? metadata,
  }) async {
    AppLogger.info('Sending interactive $type message to chat #$chatId');
    return _apiClient.post<ChatMessageItem>(
      '/mobile/chat/messages.php',
      data: {
        'chat_id': chatId,
        'type': type,
        'content': content,
        'metadata': metadata ?? {},
      },
      parser: (data) => ChatMessageItem.fromJson(data as Map<String, dynamic>),
    );
  }

  /// Marks a conversation as read
  Future<Result<bool>> markAsRead(String chatId) async {
    return _apiClient.post<bool>(
      '/mobile/chat/read.php',
      data: {'chat_id': chatId},
      parser: (data) => true,
    );
  }

  /// Emits typing indicator to recipient
  Future<Result<bool>> sendTyping(String chatId, bool isTyping) async {
    return _apiClient.post<bool>(
      '/mobile/chat/typing.php',
      data: {'chat_id': chatId, 'is_typing': isTyping},
      parser: (data) => true,
    );
  }
}
