import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
import '../models/activity_models.dart';

class ActivityRepository {
  final ApiClient _apiClient;

  ActivityRepository(this._apiClient);

  /// Fetches merchant activity feed
  Future<Result<List<MerchantActivityItem>>> getActivities({String? serviceKey}) async {
    return _apiClient.get<List<MerchantActivityItem>>(
      '/mobile/activity/index.php',
      queryParameters: serviceKey != null ? {'service_key': serviceKey} : null,
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list
              .map((item) => MerchantActivityItem.fromJson(item as Map<String, dynamic>))
              .toList();
        }
        return [];
      },
    );
  }
}
