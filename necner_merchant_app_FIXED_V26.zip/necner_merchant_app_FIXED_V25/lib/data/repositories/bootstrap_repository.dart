import '../../core/constants/api_endpoints.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
import '../models/bootstrap_config.dart';

class BootstrapRepository {
  final ApiClient _apiClient;

  BootstrapRepository(this._apiClient);

  Future<Result<BootstrapConfig>> fetchBootstrapConfig() async {
    return _apiClient.getBootstrap<BootstrapConfig>(
      ApiEndpoints.bootstrap,
      parser: (data) => BootstrapConfig.fromJson(data as Map<String, dynamic>),
    );
  }
}
