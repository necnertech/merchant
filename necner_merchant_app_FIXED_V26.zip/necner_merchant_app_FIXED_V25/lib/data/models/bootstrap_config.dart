import 'package:flutter/foundation.dart';

@immutable
class BootstrapConfig {
  final String configVersion;
  final String apiBaseUrl;
  final String realtimeBaseUrl;
  final String minimumAppVersion;
  final bool maintenanceMode;
  final bool forceUpdate;
  final Map<String, bool> featureFlags;

  const BootstrapConfig({
    required this.configVersion,
    required this.apiBaseUrl,
    required this.realtimeBaseUrl,
    required this.minimumAppVersion,
    required this.maintenanceMode,
    required this.forceUpdate,
    required this.featureFlags,
  });

  factory BootstrapConfig.fromJson(Map<String, dynamic> json) {
    final rawFlags = json['feature_flags'];
    final flags = <String, bool>{};
    if (rawFlags is Map<String, dynamic>) {
      rawFlags.forEach((key, val) {
        flags[key] = val == true || val == 1;
      });
    }

    return BootstrapConfig(
      configVersion: json['config_version'] as String? ?? '1.0.0',
      apiBaseUrl: json['api_base_url'] as String? ?? '',
      realtimeBaseUrl: json['realtime_base_url'] as String? ?? '',
      minimumAppVersion: json['minimum_app_version'] as String? ?? '1.0.0',
      maintenanceMode: json['maintenance_mode'] as bool? ?? false,
      forceUpdate: json['force_update'] as bool? ?? false,
      featureFlags: flags,
    );
  }

  Map<String, dynamic> toJson() => {
        'config_version': configVersion,
        'api_base_url': apiBaseUrl,
        'realtime_base_url': realtimeBaseUrl,
        'minimum_app_version': minimumAppVersion,
        'maintenance_mode': maintenanceMode,
        'force_update': forceUpdate,
        'feature_flags': featureFlags,
      };
}
