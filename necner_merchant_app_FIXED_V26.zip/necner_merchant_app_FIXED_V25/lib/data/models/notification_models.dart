/// Models for Notifications and Native Push Payload in Necner Merchant App
library;

class PushNotificationItem {
  final String id;
  final String type; // 'order' | 'appointment' | 'chat' | 'system' | 'payment'
  final String title;
  final String body;
  final String serviceKey;
  final String entityType;
  final String entityId;
  final bool isRead;
  final String createdAt;
  final String? deepLink;

  const PushNotificationItem({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.serviceKey,
    required this.entityType,
    required this.entityId,
    required this.isRead,
    required this.createdAt,
    this.deepLink,
  });

  factory PushNotificationItem.fromJson(Map<String, dynamic> json) {
    // Generate default deep link if not explicitly provided
    String? link = json['deep_link']?.toString();
    final sKey = json['service_key']?.toString() ?? 'system';
    final eType = json['entity_type']?.toString() ?? 'alert';
    final eId = json['entity_id']?.toString() ?? '1';

    if (link == null || link.isEmpty) {
      if (eType == 'chat' || json['type'] == 'chat') {
        link = 'necner://chat/$eId';
      } else if (sKey.isNotEmpty && sKey != 'system') {
        link = 'necner://services/$sKey';
      } else {
        link = 'necner://notifications/${json['id']}';
      }
    }

    return PushNotificationItem(
      id: json['id']?.toString() ?? '',
      type: json['type']?.toString() ?? 'system',
      title: json['title']?.toString() ?? 'Notification',
      body: json['body']?.toString() ?? '',
      serviceKey: sKey,
      entityType: eType,
      entityId: eId,
      isRead: json['is_read'] == true || json['is_read'] == 1,
      createdAt: json['created_at']?.toString() ?? '',
      deepLink: link,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type,
    'title': title,
    'body': body,
    'service_key': serviceKey,
    'entity_type': entityType,
    'entity_id': entityId,
    'is_read': isRead,
    'created_at': createdAt,
    'deep_link': deepLink,
  };

  PushNotificationItem copyWith({
    String? id,
    String? type,
    String? title,
    String? body,
    String? serviceKey,
    String? entityType,
    String? entityId,
    bool? isRead,
    String? createdAt,
    String? deepLink,
  }) {
    return PushNotificationItem(
      id: id ?? this.id,
      type: type ?? this.type,
      title: title ?? this.title,
      body: body ?? this.body,
      serviceKey: serviceKey ?? this.serviceKey,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      isRead: isRead ?? this.isRead,
      createdAt: createdAt ?? this.createdAt,
      deepLink: deepLink ?? this.deepLink,
    );
  }
}
