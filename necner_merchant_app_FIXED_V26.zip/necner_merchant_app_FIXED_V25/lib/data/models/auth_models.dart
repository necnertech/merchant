import 'package:flutter/foundation.dart';

@immutable
class LoginRequest {
  final String identifier; // Username or Email
  final String password;
  final String deviceId;
  final String platform; // "android" or "ios"
  final String appVersion;

  const LoginRequest({
    required this.identifier,
    required this.password,
    required this.deviceId,
    required this.platform,
    required this.appVersion,
  });

  Map<String, dynamic> toJson() => {
        'identifier': identifier,
        'password': password,
        'device_id': deviceId,
        'platform': platform,
        'app_version': appVersion,
      };
}

@immutable
class MerchantUser {
  final int id;
  final String name;
  final String email;
  final String role;
  final String? avatarUrl;

  const MerchantUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.avatarUrl,
  });

  factory MerchantUser.fromJson(Map<String, dynamic> json) {
    return MerchantUser(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? 'Merchant',
      email: json['email'] as String? ?? '',
      role: json['role'] as String? ?? 'merchant',
      avatarUrl: json['avatar_url'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'role': role,
        'avatar_url': avatarUrl,
      };

  MerchantUser copyWith({String? name, String? email, String? role, String? avatarUrl}) {
    return MerchantUser(id:id,name:name??this.name,email:email??this.email,role:role??this.role,avatarUrl:avatarUrl??this.avatarUrl);
  }
}

@immutable
class MerchantTenant {
  final int id;
  final String name;
  final String? businessType;

  const MerchantTenant({
    required this.id,
    required this.name,
    this.businessType,
  });

  factory MerchantTenant.fromJson(Map<String, dynamic> json) {
    return MerchantTenant(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? 'Business',
      businessType: json['business_type'] as String? ?? 'General',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'business_type': businessType,
      };

  MerchantTenant copyWith({String? name, String? businessType}) {
    return MerchantTenant(id:id,name:name??this.name,businessType:businessType??this.businessType);
  }
}

@immutable
class AuthTokens {
  final String accessToken;
  final String refreshToken;
  final String tokenType;
  final int expiresIn;
  final DateTime expiresAt;

  const AuthTokens({
    required this.accessToken,
    required this.refreshToken,
    required this.tokenType,
    required this.expiresIn,
    required this.expiresAt,
  });

  factory AuthTokens.fromJson(Map<String, dynamic> json) {
    final expiresIn = json['expires_in'] as int? ?? 3600;
    final expiresAtStr = json['expires_at'] as String?;
    final expiresAt = expiresAtStr != null
        ? (DateTime.tryParse(expiresAtStr) ?? DateTime.now().add(Duration(seconds: expiresIn)))
        : DateTime.now().add(Duration(seconds: expiresIn));

    return AuthTokens(
      accessToken: json['access_token'] as String,
      refreshToken: json['refresh_token'] as String? ?? '',
      tokenType: json['token_type'] as String? ?? 'Bearer',
      expiresIn: expiresIn,
      expiresAt: expiresAt,
    );
  }
}

@immutable
class AuthSession {
  final MerchantUser user;
  final MerchantTenant tenant;
  final List<String> effectivePermissions;
  final List<String> assignedServices;

  const AuthSession({
    required this.user,
    required this.tenant,
    this.effectivePermissions = const [],
    this.assignedServices = const [],
  });

  factory AuthSession.fromJson(Map<String, dynamic> json) {
    final userData = json['user'] as Map<String, dynamic>? ?? {};
    final tenantData = json['tenant'] as Map<String, dynamic>? ?? {};
    final permsRaw = json['effective_permissions'] as List<dynamic>? ?? [];
    final svcsRaw = json['assigned_services'] as List<dynamic>? ?? [];

    return AuthSession(
      user: MerchantUser.fromJson(userData),
      tenant: MerchantTenant.fromJson(tenantData),
      effectivePermissions: permsRaw.map((e) => e.toString()).toList(),
      assignedServices: svcsRaw.map((e) => e.toString()).toList(),
    );
  }
}
