package com.necner.merchant

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
